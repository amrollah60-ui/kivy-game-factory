# -*- coding: utf-8 -*-
"""بانک کلمات آسان - ۴۰۰ کلمه روزمره"""

EASY_WORDS = [
    # ===== ۳ حرفی (۵۰ عدد) =====
    "ACE", "ACT", "ADD", "AGE", "AID", "AIM", "AIR", "ALL", "AND", "ANT",
    "ANY", "APE", "ARC", "ARE", "ARK", "ARM", "ART", "ASH", "ASK", "ATE",
    "AWE", "AXE", "BAD", "BAG", "BAN", "BAR", "BAT", "BAY", "BED", "BEE",
    "BET", "BID", "BIG", "BIN", "BIT", "BOW", "BOX", "BOY", "BUD", "BUG",
    "BUN", "BUS", "BUT", "BUY", "CAB", "CAM", "CAP", "CAR", "CAT", "COP",
    
    # ===== ۴ حرفی (۱۵۰ عدد) =====
    "ABLE", "ACHY", "ACID", "ACRE", "AHA", "AIDS", "ALAS", "ALPS", "AMEN", "AMID",
    "AMMO", "AMOK", "AMPS", "ANAL", "ANEW", "ANGRY", "ANTI", "ANTS", "APPS", "ARCH",
    "AREA", "ARGO", "ARID", "ARMS", "ARMY", "ASIA", "ATOM", "AURA", "AVID", "AXLE",
    "AXON", "BABY", "BACK", "BAGS", "BAIT", "BAKE", "BALD", "BALE", "BALL", "BAND",
    "BANG", "BANK", "BARE", "BARK", "BARN", "BASE", "BASH", "BASK", "BASS", "BATH",
    "BEAD", "BEAK", "BEAM", "BEAN", "BEAR", "BEAT", "BEEF", "BEEN", "BEER", "BELL",
    "BELT", "BEND", "BENT", "BEST", "BETS", "BIAS", "BIKE", "BILE", "BIND", "BITE",
    "BLUE", "BLUR", "BOAR", "BOAT", "BODY", "BOIL", "BOLD", "BOLT", "BOMB", "BOND",
    "BOOK", "BOOM", "BOOT", "BORE", "BOSS", "BOTH", "BOWL", "BOWS", "BREW", "BRIM",
    "BROW", "BUCK", "BUFF", "BULB", "BULK", "BULL", "BUMP", "BUNK", "BUNT", "BURY",
    "BUSY", "BUTT", "BUZZ", "CABS", "CAGE", "CAKE", "CALF", "CALL", "CALM", "CAME",
    "CAMP", "CANE", "CAPE", "CARD", "CARE", "CART", "CASE", "CASH", "CAST", "CAVE",
    "CELL", "CENT", "CHAP", "CHAR", "CHAT", "CHEF", "CHEW", "CHIC", "CHIN", "CHIP",
    "CHIT", "CHOP", "CHOW", "CHUB", "CHUG", "CHUM", "CITY", "CLAD", "CLAM", "CLAN",
    "CLAP", "CLAW", "CLAY", "CLOD", "CLOG", "CLOT", "CLUB", "CLUE", "COAL", "COAT",
    
    # ===== ۵ حرفی (۱۰۰ عدد) =====
    "ABOUT", "ABOVE", "ACTOR", "ADAPT", "ADORE", "ADULT", "AFTER", "AGAIN", "AGENT", "AGILE",
    "AGING", "AGONY", "AGREE", "AHEAD", "ALARM", "ALBUM", "ALERT", "ALIEN", "ALIKE", "ALIVE",
    "ALLEY", "ALLOW", "ALONE", "ALONG", "ALTER", "AMONG", "ANGEL", "ANGER", "ANGLE", "ANGRY",
    "ANIME", "ANKLE", "ARENA", "ARISE", "ARRAY", "AUDIO", "AWAKE", "AWARD", "AWARE", "AWFUL",
    "BABEL", "BABY", "BAGEL", "BAKER", "BALKY", "BALLS", "BANAL", "BANJO", "BARON", "BASAL",
    "BASIC", "BASIN", "BATCH", "BEACH", "BEAST", "BEGAN", "BEGUN", "BEING", "BELCH", "BELLY",
    "BENCH", "BERRY", "BIBLE", "BIRTH", "BLACK", "BLADE", "BLAME", "BLAND", "BLAST", "BLAZE",
    "BLEED", "BLEND", "BLESS", "BLIND", "BLINK", "BLISS", "BLOCK", "BLOOD", "BLOW", "BLUE",
    "BLUFF", "BLUNT", "BLURT", "BLUSH", "BOARD", "BOAST", "BONUS", "BOOST", "BOOTH", "BOUND",
    "BRAIN", "BRAKE", "BRASS", "BRAVE", "BREAD", "BREAK", "BREED", "BRIDE", "BRING", "BROAD",
    
    # ===== ۶ حرفی (۱۰۰ عدد) =====
    "ABROAD", "ABSORB", "ACCESS", "ACROSS", "ACTION", "ACTIVE", "ACTUAL", "ADVICE", "AFFECT", "AFFORD",
    "AFRAID", "ALWAYS", "ANIMAL", "APPEAL", "APPEAR", "AROUND", "ARTIST", "ASSIGN", "ASSIST", "ATTACH",
    "ATTACK", "ATTEMPT", "ATTEND", "AUGUST", "BALANCE", "BALLOT", "BANKER", "BARRIER", "BATTER", "BATTLE",
    "BEARING", "BEATEN", "BECOME", "BEFORE", "BEGIN", "BEHAVE", "BELONG", "BENEATH", "BENEFIT", "BETTER",
    "BETWEEN", "BEYOND", "BISHOP", "BITTER", "BLANKET", "BLAZER", "BLEACH", "BLOOM", "BOILER", "BORROW",
    "BOTTLE", "BOTTOM", "BOWING", "BRANCH", "BREAKER", "BREATH", "BRIDGE", "BRIEF", "BRIGHT", "BROKEN",
    "BROKER", "BROTHER", "BROWSE", "BUDGET", "BUILDER", "BUNDLE", "BURDEN", "BUREAU", "BUTTER", "BUTTON",
    "CABINET", "CAMERA", "CAMPUS", "CANADA", "CANCER", "CANDID", "CAPABLE", "CAPITAL", "CAPTURE", "CARBON",
    "CAREER", "CARPET", "CARROT", "CARRY", "CASUAL", "CATALOG", "CATCHER", "CAUSAL", "CEILING", "CENTRAL",
    "CENTURY", "CEREAL", "CHAIRMAN", "CHAMBER", "CHANGE", "CHARGE", "CHEESE", "CHICKEN", "CHILDREN", "CHINA",
]

def get_words():
    return EASY_WORDS

def get_count():
    return len(EASY_WORDS)