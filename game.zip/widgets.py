# -*- coding: utf-8 -*-
"""
widgets.py - ویجت‌های سفارشی بازی
"""

import math
from kivy.uix.relativelayout import RelativeLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.graphics import Color, Line, Ellipse
from kivy.metrics import dp
from utils import FONT_BOLD

class CloverWidget(RelativeLayout):
    def __init__(self, letters, on_word_drawn=None, **kwargs):
        super(CloverWidget, self).__init__(**kwargs)
        self.letters = letters
        self.on_word_drawn = on_word_drawn
        self.letter_buttons = {}
        self.selected_indices = []
        self.swipe_indices = []
        self.is_drawing = False
        self._setup_clover()
        self.bind(size=self._update_clover)
    
    def _update_clover(self, *args):
        self._setup_clover()
    
    def _setup_clover(self):
        self.clear_widgets()
        self.canvas.clear()
        self.letter_buttons.clear()
        
        num_letters = len(self.letters)
        if num_letters == 0:
            return
        
        w, h = self.size
        center_x = w / 2
        center_y = h / 2
        radius = min(w, h) * 0.35
        letter_size = min(dp(50), radius * 0.6)
        font_size = min(dp(24), radius * 0.4)
        
        with self.canvas:
            Color(0.1, 0.5, 0.2, 0.3)
            Line(circle=(center_x, center_y, radius + 10), width=2)
        
        for i, letter in enumerate(self.letters):
            angle = (2 * math.pi / num_letters) * i - math.pi / 2
            x = center_x + radius * math.cos(angle) - letter_size / 2
            y = center_y + radius * math.sin(angle) - letter_size / 2
            
            is_selected = i in self.selected_indices
            
            btn = Button(
                text=letter,
                font_size=font_size,
                font_name=FONT_BOLD,
                size_hint=(None, None),
                size=(letter_size, letter_size),
                pos=(x, y),
                background_color=(1, 0.5, 0, 0.6) if is_selected else (0, 0.6, 0.25, 0.8),
                color=(1, 0.8, 0, 1)
            )
            
            with btn.canvas.before:
                Color(1, 0.5, 0, 0.6) if is_selected else Color(0, 0.6, 0.25, 0.8)
                Ellipse(pos=(x, y), size=(letter_size, letter_size))
                Color(1, 1, 1, 0.1)
                Line(circle=(x + letter_size/2, y + letter_size/2, letter_size/2), width=1.5)
            
            self.add_widget(btn)
            self.letter_buttons[i] = (x + letter_size/2, y + letter_size/2)
    
    def on_touch_down(self, touch):
        if self.collide_point(*touch.pos) and len(self.letters) > 0:
            self.is_drawing = True
            self.swipe_indices = []
            self.selected_indices = []
            self._check_collision(touch.pos)
            return True
        return super(CloverWidget, self).on_touch_down(touch)
    
    def on_touch_move(self, touch):
        if self.is_drawing and self.collide_point(*touch.pos):
            self._check_collision(touch.pos)
            self._redraw_lines(touch.pos)
            return True
        return super(CloverWidget, self).on_touch_move(touch)
    
    def on_touch_up(self, touch):
        if self.is_drawing:
            self.is_drawing = False
            self.canvas.remove_group('swipe_lines')
            
            if len(self.swipe_indices) >= 2:
                word = "".join([self.letters[i] for i in self.swipe_indices])
                if self.on_word_drawn:
                    self.on_word_drawn(word)
            
            self.swipe_indices = []
            self.selected_indices = []
            self._setup_clover()
            return True
        return super(CloverWidget, self).on_touch_up(touch)
    
    def _check_collision(self, pos):
        local_pos = self.to_widget(*pos)
        for idx, center in self.letter_buttons.items():
            dist = math.sqrt((local_pos[0] - center[0])**2 + (local_pos[1] - center[1])**2)
            if dist < dp(30) and idx not in self.swipe_indices:
                self.swipe_indices.append(idx)
                if idx not in self.selected_indices:
                    self.selected_indices.append(idx)
                self._setup_clover()
                break
    
    def _redraw_lines(self, current_pos):
        self.canvas.remove_group('swipe_lines')
        if len(self.swipe_indices) < 2:
            return
        
        local_mouse = self.to_widget(*current_pos)
        with self.canvas:
            Color(1, 0.75, 0, 1, group='swipe_lines')
            points = []
            for idx in self.swipe_indices:
                points.extend(self.letter_buttons[idx])
            points.extend(local_mouse)
            if len(points) >= 4:
                Line(points=points, width=4, group='swipe_lines')
    
    def update_letters(self, new_letters):
        self.letters = new_letters
        self.selected_indices = []
        self.swipe_indices = []
        self._setup_clover()