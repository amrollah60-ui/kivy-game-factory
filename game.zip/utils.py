# -*- coding: utf-8 -*-
"""
utils.py - ابزارهای عمومی بازی
"""

import os
import json
import uuid
import random
import math

# ============================================================
# Font Settings
# ============================================================
FONT_REGULAR = "C:\\Windows\\Fonts\\arial.ttf"
FONT_BOLD = "C:\\Windows\\Fonts\\arialbd.ttf"

# ============================================================
# Session Management
# ============================================================
SESSION_FILE = "session.json"

def get_session():
    if os.path.exists(SESSION_FILE):
        try:
            with open(SESSION_FILE, "r") as f:
                data = json.load(f)
                if "user_uuid" in data:
                    return data["user_uuid"]
        except:
            pass
    user_uuid = str(uuid.uuid4())
    with open(SESSION_FILE, "w") as f:
        json.dump({"user_uuid": user_uuid}, f)
    return user_uuid

def set_popup_shown():
    if os.path.exists(SESSION_FILE):
        try:
            with open(SESSION_FILE, "r") as f:
                data = json.load(f)
            data["popup_shown"] = True
            with open(SESSION_FILE, "w") as f:
                json.dump(data, f)
        except:
            pass

def is_popup_shown():
    if os.path.exists(SESSION_FILE):
        try:
            with open(SESSION_FILE, "r") as f:
                data = json.load(f)
                return data.get("popup_shown", False)
        except:
            pass
    return False

# ============================================================
# Avatar Data
# ============================================================
FREE_AVATARS = [
    {"id": "bald_boy", "name": "Bald Boy"},
    {"id": "bald_girl", "name": "Bald Girl"},
    {"id": "bald_old_man", "name": "Bald Old Man"},
    {"id": "bald_old_woman", "name": "Bald Old Woman"},
]

PREMIUM_AVATARS = [
    {"id": "baby", "name": "Baby", "cost": 100},
    {"id": "king", "name": "King", "cost": 100},
    {"id": "soldier", "name": "Soldier", "cost": 100},
    {"id": "hairy_man", "name": "Hairy Man", "cost": 100},
    {"id": "curly_man", "name": "Curly Man", "cost": 100},
    {"id": "big_head_man", "name": "Big Head Man", "cost": 100},
    {"id": "pretty_woman", "name": "Pretty Woman", "cost": 100},
    {"id": "handsome_man", "name": "Handsome Man", "cost": 100},
    {"id": "angry_man", "name": "Angry Man", "cost": 100},
    {"id": "strong_man", "name": "Strong Man", "cost": 100},
    {"id": "angry_woman", "name": "Angry Woman", "cost": 100},
    {"id": "strong_woman", "name": "Strong Woman", "cost": 100},
    {"id": "athlete_man", "name": "Athlete Man", "cost": 100},
    {"id": "athlete_woman", "name": "Athlete Woman", "cost": 100},
    {"id": "old_man", "name": "Old Man", "cost": 100},
    {"id": "old_woman", "name": "Old Woman", "cost": 100},
]

ALL_AVATARS = FREE_AVATARS + PREMIUM_AVATARS

def get_avatar_name(avatar_id):
    for av in ALL_AVATARS:
        if av["id"] == avatar_id:
            return av["name"]
    return avatar_id

def get_avatar_cost(avatar_id):
    for av in PREMIUM_AVATARS:
        if av["id"] == avatar_id:
            return av["cost"]
    return 0

# ============================================================
# Dictionary Validation
# ============================================================
try:
    import enchant
    DICT = enchant.Dict("en_US")
    DICT_AVAILABLE = True
    print("✅ Dictionary loaded successfully!")
except:
    DICT_AVAILABLE = False
    print("⚠️ PyEnchant not installed! Install with: pip install pyenchant")

def is_valid_word(word):
    if not word or len(word) < 2:
        return False
    word = word.upper()
    if not word.isalpha():
        return False
    if DICT_AVAILABLE:
        try:
            return DICT.check(word.lower())
        except:
            return True
    return True

# ============================================================
# Word Bank Loader
# ============================================================
def load_word_banks():
    import sys
    import os
    easy_words = []
    medium_words = []
    hard_words = []
    special_words = []
    
    try:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        
        from word_banks.bank_easy import get_words as get_easy
        from word_banks.bank_medium import get_words as get_medium
        from word_banks.bank_hard import get_words as get_hard
        from word_banks.bank_special import get_words as get_special
        
        easy_words = get_easy()
        medium_words = get_medium()
        hard_words = [item["word"] for item in get_hard()]
        special_words = [item["word"] for item in get_special()]
        
        print(f"✅ Loaded banks: Easy={len(easy_words)}, Medium={len(medium_words)}, Hard={len(hard_words)}, Special={len(special_words)}")
    except Exception as e:
        print(f"⚠️ Error loading banks: {e}")
        easy_words = ["TEA", "EAT", "AT", "BOOK", "OK", "WATER", "ATE", "HAPPY", "HAP"]
        medium_words = ["TEACH", "CHEAT", "REACH", "HE", "STAR", "ART", "RAT", "TAR"]
        hard_words = ["ALGORITHM", "QUANTUM", "ENTROPY", "GRAVITY", "PROTON", "ELECTRON"]
        special_words = ["BIOTECHNOLOGY", "NANOTECHNOLOGY", "ASTROPHYSICS", "NEUROSCIENCE"]
    
    return easy_words, medium_words, hard_words, special_words

EASY_WORDS, MEDIUM_WORDS, HARD_WORDS, SPECIAL_WORDS = load_word_banks()

# ============================================================
# Generate sub-words - IMPROVED
# ============================================================
def generate_sub_words(main_word, min_sub_words=4):
    """Generate sub-words with minimum 4 options for all words"""
    letters = list(main_word)
    sub_words = []
    
    # فقط کلمات معتبر رو نگه میداریم
    # 2-letter words
    for i in range(len(letters)):
        for j in range(i+1, len(letters)):
            w = letters[i] + letters[j]
            if is_valid_word(w) and w != main_word and w not in sub_words:
                sub_words.append(w)
            w2 = letters[j] + letters[i]
            if is_valid_word(w2) and w2 != main_word and w2 not in sub_words:
                sub_words.append(w2)
    
    # 3-letter words
    for i in range(len(letters)):
        for j in range(i+1, len(letters)):
            for k in range(j+1, len(letters)):
                perms = [
                    letters[i] + letters[j] + letters[k],
                    letters[i] + letters[k] + letters[j],
                    letters[j] + letters[i] + letters[k],
                    letters[j] + letters[k] + letters[i],
                    letters[k] + letters[i] + letters[j],
                    letters[k] + letters[j] + letters[i]
                ]
                for w in perms:
                    if is_valid_word(w) and w != main_word and w not in sub_words:
                        sub_words.append(w)
    
    # 4-letter words
    if len(letters) >= 4:
        import itertools
        for combo in itertools.combinations(letters, 4):
            for perm in set(itertools.permutations(combo)):
                w = ''.join(perm)
                if is_valid_word(w) and w != main_word and w not in sub_words:
                    sub_words.append(w)
                    if len(sub_words) >= min_sub_words + 2:
                        break
            if len(sub_words) >= min_sub_words + 2:
                break
    
    # 5-letter words
    if len(sub_words) < min_sub_words and len(letters) >= 5:
        import itertools
        for combo in itertools.combinations(letters, 5):
            for perm in set(itertools.permutations(combo)):
                w = ''.join(perm)
                if is_valid_word(w) and w != main_word and w not in sub_words:
                    sub_words.append(w)
                    if len(sub_words) >= min_sub_words + 2:
                        break
            if len(sub_words) >= min_sub_words + 2:
                break
    
    # اگر به اندازه کافی زیرکلمه نداشت، همون تعداد موجود رو برگردون
    if len(sub_words) < min_sub_words:
        return sub_words[:len(sub_words)]
    
    return sub_words[:min_sub_words + 2]

# ============================================================
# Word Explanation (زیرنویس کلمات)
# ============================================================
def get_word_explanation(word):
    """دریافت توضیح کلمه از بانک‌های کلمات"""
    word = word.upper().strip()
    
    # اول از فایل word_bank_complete.json چک میکنیم
    try:
        import json
        with open("word_bank_complete.json", "r", encoding="utf-8") as f:
            data = json.load(f)
        
        # جستجو در همه سطح‌ها
        for level_num, trays in data.get("levels", {}).items():
            for tray in trays:
                word_data = tray.get("word_data", {})
                if word in word_data:
                    # اگر توضیح داشت برگردون
                    if "explanations" in word_data[word]:
                        return word_data[word]["explanations"].get("en", word)
                    # اگر ترجمه داشت برگردون
                    elif "translations" in word_data[word]:
                        return word_data[word]["translations"].get("en", word)
    except:
        pass
    
    # اگر در فایل نبود، از دیکشنری ساده چک میکنیم
    try:
        with open("dictionary.txt", "r", encoding="utf-8") as f:
            dict_words = [line.strip().upper() for line in f.readlines()]
        if word in dict_words:
            return word
    except:
        pass
    
    # در نهایت خود کلمه رو برگردون
    
    return word
    
    # -*- coding: utf-8 -*-
"""
utils.py - ابزارهای عمومی بازی
"""

import os
import json
import uuid
import random
import math

# ============================================================
# Font Settings
# ============================================================
FONT_REGULAR = "C:\\Windows\\Fonts\\arial.ttf"
FONT_BOLD = "C:\\Windows\\Fonts\\arialbd.ttf"

# ============================================================
# Session Management
# ============================================================
SESSION_FILE = "session.json"

def get_session():
    if os.path.exists(SESSION_FILE):
        try:
            with open(SESSION_FILE, "r") as f:
                data = json.load(f)
                if "user_uuid" in data:
                    return data["user_uuid"]
        except:
            pass
    user_uuid = str(uuid.uuid4())
    with open(SESSION_FILE, "w") as f:
        json.dump({"user_uuid": user_uuid}, f)
    return user_uuid

def set_popup_shown():
    if os.path.exists(SESSION_FILE):
        try:
            with open(SESSION_FILE, "r") as f:
                data = json.load(f)
            data["popup_shown"] = True
            with open(SESSION_FILE, "w") as f:
                json.dump(data, f)
        except:
            pass

def is_popup_shown():
    if os.path.exists(SESSION_FILE):
        try:
            with open(SESSION_FILE, "r") as f:
                data = json.load(f)
                return data.get("popup_shown", False)
        except:
            pass
    return False

# ============================================================
# Avatar Data
# ============================================================
FREE_AVATARS = [
    {"id": "bald_boy", "name": "Bald Boy"},
    {"id": "bald_girl", "name": "Bald Girl"},
    {"id": "bald_old_man", "name": "Bald Old Man"},
    {"id": "bald_old_woman", "name": "Bald Old Woman"},
]

PREMIUM_AVATARS = [
    {"id": "baby", "name": "Baby", "cost": 100},
    {"id": "king", "name": "King", "cost": 100},
    {"id": "soldier", "name": "Soldier", "cost": 100},
    {"id": "hairy_man", "name": "Hairy Man", "cost": 100},
    {"id": "curly_man", "name": "Curly Man", "cost": 100},
    {"id": "big_head_man", "name": "Big Head Man", "cost": 100},
    {"id": "pretty_woman", "name": "Pretty Woman", "cost": 100},
    {"id": "handsome_man", "name": "Handsome Man", "cost": 100},
    {"id": "angry_man", "name": "Angry Man", "cost": 100},
    {"id": "strong_man", "name": "Strong Man", "cost": 100},
    {"id": "angry_woman", "name": "Angry Woman", "cost": 100},
    {"id": "strong_woman", "name": "Strong Woman", "cost": 100},
    {"id": "athlete_man", "name": "Athlete Man", "cost": 100},
    {"id": "athlete_woman", "name": "Athlete Woman", "cost": 100},
    {"id": "old_man", "name": "Old Man", "cost": 100},
    {"id": "old_woman", "name": "Old Woman", "cost": 100},
]

ALL_AVATARS = FREE_AVATARS + PREMIUM_AVATARS

def get_avatar_name(avatar_id):
    for av in ALL_AVATARS:
        if av["id"] == avatar_id:
            return av["name"]
    return avatar_id

def get_avatar_cost(avatar_id):
    for av in PREMIUM_AVATARS:
        if av["id"] == avatar_id:
            return av["cost"]
    return 0

# ============================================================
# Avatar Display Functions (اضافه شده)
# ============================================================
def get_avatar_display(avatar_path):
    """
    دریافت نام نمایشی برای آواتار
    اگر آواتار سفارشی باشه، "📸 Custom Photo" برمیگردونه
    """
    if avatar_path and avatar_path.startswith("avatars/"):
        return "📸 Custom Photo"
    return get_avatar_name(avatar_path)

def get_avatar_icon(avatar_path):
    """
    دریافت آیکون برای آواتار
    اگر آواتار سفارشی باشه، "📸" برمیگردونه
    """
    if avatar_path and avatar_path.startswith("avatars/"):
        return "📸"
    # برای آواتارهای پیش‌فرض از ایموجی استفاده کن
    for av in ALL_AVATARS:
        if av["id"] == avatar_path:
            return "🖼️"
    return "🖼️"

def is_custom_avatar(avatar_path):
    """بررسی اینکه آیا آواتار سفارشی (عکس کاربر) است یا خیر"""
    return avatar_path and avatar_path.startswith("avatars/")

# ============================================================
# Avatar Image Functions
# ============================================================
AVATAR_FOLDER = "avatars"

def save_custom_avatar(user_uuid, image_path):
    """
    ذخیره عکس آواتار سفارشی کاربر
    """
    try:
        from PIL import Image
        import os
        
        # ایجاد پوشه avatars اگر وجود نداشت
        os.makedirs(AVATAR_FOLDER, exist_ok=True)
        
        # باز کردن و تغییر سایز عکس
        img = Image.open(image_path)
        
        # تبدیل به RGB اگر RGBA بود
        if img.mode == 'RGBA':
            img = img.convert('RGB')
        
        # تغییر سایز به 150x150
        img = img.resize((150, 150), Image.Resampling.LANCZOS)
        
        # ذخیره با نام user_uuid.png
        save_path = os.path.join(AVATAR_FOLDER, f"{user_uuid}.png")
        img.save(save_path, 'PNG')
        
        return save_path
    except Exception as e:
        print(f"❌ Error saving avatar: {e}")
        return None

def delete_custom_avatar(user_uuid):
    """حذف عکس آواتار سفارشی کاربر"""
    try:
        avatar_path = os.path.join(AVATAR_FOLDER, f"{user_uuid}.png")
        if os.path.exists(avatar_path):
            os.remove(avatar_path)
            return True
    except:
        pass
    return False

# ============================================================
# Dictionary Validation
# ============================================================
try:
    import enchant
    DICT = enchant.Dict("en_US")
    DICT_AVAILABLE = True
    print("✅ Dictionary loaded successfully!")
except:
    DICT_AVAILABLE = False
    print("⚠️ PyEnchant not installed! Install with: pip install pyenchant")

def is_valid_word(word):
    if not word or len(word) < 2:
        return False
    word = word.upper()
    if not word.isalpha():
        return False
    if DICT_AVAILABLE:
        try:
            return DICT.check(word.lower())
        except:
            return True
    return True

# ============================================================
# Word Bank Loader
# ============================================================
def load_word_banks():
    import sys
    import os
    easy_words = []
    medium_words = []
    hard_words = []
    special_words = []
    
    try:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        
        from word_banks.bank_easy import get_words as get_easy
        from word_banks.bank_medium import get_words as get_medium
        from word_banks.bank_hard import get_words as get_hard
        from word_banks.bank_special import get_words as get_special
        
        easy_words = get_easy()
        medium_words = get_medium()
        hard_words = [item["word"] for item in get_hard()]
        special_words = [item["word"] for item in get_special()]
        
        print(f"✅ Loaded banks: Easy={len(easy_words)}, Medium={len(medium_words)}, Hard={len(hard_words)}, Special={len(special_words)}")
    except Exception as e:
        print(f"⚠️ Error loading banks: {e}")
        easy_words = ["TEA", "EAT", "AT", "BOOK", "OK", "WATER", "ATE", "HAPPY", "HAP"]
        medium_words = ["TEACH", "CHEAT", "REACH", "HE", "STAR", "ART", "RAT", "TAR"]
        hard_words = ["ALGORITHM", "QUANTUM", "ENTROPY", "GRAVITY", "PROTON", "ELECTRON"]
        special_words = ["BIOTECHNOLOGY", "NANOTECHNOLOGY", "ASTROPHYSICS", "NEUROSCIENCE"]
    
    return easy_words, medium_words, hard_words, special_words

EASY_WORDS, MEDIUM_WORDS, HARD_WORDS, SPECIAL_WORDS = load_word_banks()

# ============================================================
# Generate sub-words
# ============================================================
def generate_sub_words(main_word, min_sub_words=4):
    letters = list(main_word)
    sub_words = []
    valid_common = ["AT", "IN", "ON", "IT", "IS", "AN", "AS", "AM", "HE", "WE", "BE", "BY", "DO", "GO", "HI", "IF", "ME", "MY", "NO", "OF", "OR", "SO", "TO", "UP", "US", "THE", "AND", "FOR", "ARE", "BUT", "NOT", "YOU", "ALL", "CAN", "HAD", "HER", "WAS", "ONE", "OUR", "OUT", "DAY", "GET", "HAS", "HIM", "HOW", "MAN", "NEW", "NOW", "OLD", "SEE", "TWO", "WAY", "BED", "DOG", "CAT", "SUN", "HOT", "SAD", "BIG", "COW", "PIG", "HEN", "FOX", "OWL", "RAT", "BAT", "HAT", "CAP", "MAP"]
    
    for i in range(len(letters)):
        for j in range(i+1, len(letters)):
            w = letters[i] + letters[j]
            if w in valid_common and w != main_word and w not in sub_words:
                sub_words.append(w)
    
    for i in range(len(letters)):
        for j in range(i+1, len(letters)):
            for k in range(j+1, len(letters)):
                w = letters[i] + letters[j] + letters[k]
                if w in valid_common and w != main_word and w not in sub_words:
                    sub_words.append(w)
    
    if len(sub_words) < min_sub_words:
        for i in range(len(letters)):
            for j in range(i+1, len(letters)):
                for k in range(j+1, len(letters)):
                    for l in range(k+1, len(letters)):
                        if len(letters) >= 4:
                            w = letters[i] + letters[j] + letters[k] + letters[l]
                            if is_valid_word(w) and w != main_word and w not in sub_words:
                                sub_words.append(w)
                                if len(sub_words) >= min_sub_words:
                                    break
                    if len(sub_words) >= min_sub_words:
                        break
                if len(sub_words) >= min_sub_words:
                    break
            if len(sub_words) >= min_sub_words:
                break
    
    if len(sub_words) < min_sub_words and len(letters) >= 5:
        import itertools
        for combo in itertools.combinations(letters, 5):
            w = ''.join(combo)
            if is_valid_word(w) and w != main_word and w not in sub_words:
                sub_words.append(w)
                if len(sub_words) >= min_sub_words:
                    break
    
    return sub_words[:6]

# ============================================================
# Word Explanation
# ============================================================
def get_word_explanation(word):
    word = word.upper().strip()
    
    try:
        import json
        with open("word_bank_complete.json", "r", encoding="utf-8") as f:
            data = json.load(f)
        
        for level_num, trays in data.get("levels", {}).items():
            for tray in trays:
                word_data = tray.get("word_data", {})
                if word in word_data:
                    if "explanations" in word_data[word]:
                        return word_data[word]["explanations"].get("en", word)
                    elif "translations" in word_data[word]:
                        return word_data[word]["translations"].get("en", word)
    except:
        pass
    
    try:
        with open("dictionary.txt", "r", encoding="utf-8") as f:
            dict_words = [line.strip().upper() for line in f.readlines()]
        if word in dict_words:
            return word
    except:
        pass
    
    return word