# -*- coding: utf-8 -*-
"""
LepreCoin - Ultimate Stable Version
Compatible with Android 5 to 14+
"""

import kivy
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.relativelayout import RelativeLayout
from kivy.uix.button import Button
from kivy.uix.gridlayout import GridLayout
from kivy.uix.textinput import TextInput
from kivy.uix.scrollview import ScrollView
from kivy.uix.image import Image
from kivy.uix.widget import Widget
from kivy.core.window import Window
from kivy.graphics import Color, Line, Ellipse, Rectangle
from kivy.clock import Clock
from kivy.metrics import dp
from kivy.utils import platform
import math
import random
import os
import sys
import sqlite3
import uuid
import json
from datetime import datetime
import traceback

# ============================================================
# Window Settings
# ============================================================
Window.size = (450, 750)
Window.minimum_width = 350
Window.minimum_height = 550

FONT_REGULAR = "C:\\Windows\\Fonts\\arial.ttf"
FONT_BOLD = "C:\\Windows\\Fonts\\arialbd.ttf"

# ============================================================
# AdMob Settings
# ============================================================
ADMOB_APP_ID = "ca-app-pub-3940256099942544~3347511713"
ADMOB_BANNER_ID = "ca-app-pub-3940256099942544/6300978111"
ADMOB_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712"
ADMOB_REWARDED_ID = "ca-app-pub-3940256099942544/5224354917"

ADMOB_AVAILABLE = False
try:
    from kivmob import KivMob
    ADMOB_AVAILABLE = True
    print("✅ KivMob loaded successfully!")
except ImportError:
    print("⚠️ KivMob not installed! Ads will be simulated.")
    
# ============================================================
# Safe Resource Loader (کلیدی‌ترین بخش)
# ============================================================
def safe_resource_path(filename):
    """پیدا کردن مسیر فایل به روش استاندارد در اندروید و ویندوز"""
    if platform == 'android':
        # در اندروید، فایل‌ها در پوشه‌ی assets یا داده‌ی برنامه هستند
        # ابتدا سعی می‌کنیم مسیر مطلق رو پیدا کنیم
        base_dir = os.path.dirname(os.path.abspath(__file__))
        # اگر بازی به صورت APK نصب شده، دیتا در پوشه‌ی اختصاصی است
        if os.path.exists(os.path.join(base_dir, 'images')):
            return os.path.join(base_dir, filename)
        else:
            # برخی از دستگاه‌ها از این مسیر استفاده می‌کنند
            alt_path = os.path.join('/data/data/org.leprecoin.leprecoin/files/app', filename)
            if os.path.exists(alt_path):
                return alt_path
            # در نهایت، اگر فایل وجود نداشت، مسیر نسبی را برمی‌گردانیم
            return filename
    else:
        # دسکتاپ
        return filename

def safe_load_image(source, default=None):
    """بارگذاری ایمن تصویر با fallback"""
    try:
        if source and os.path.exists(safe_resource_path(source)):
            return Image(source=safe_resource_path(source), allow_stretch=True, keep_ratio=True)
        else:
            # اگر تصویر وجود نداشت، یک placeholder برمی‌گردانیم
            print(f"⚠️ Image not found: {source}, using placeholder")
            return Label(text="🖼️", font_size=dp(30), color=(1, 1, 1, 1))
    except Exception as e:
        print(f"❌ Error loading image {source}: {e}")
        return Label(text="🖼️", font_size=dp(30), color=(1, 1, 1, 1))

# ============================================================
# Dictionary Validation (با try/except ایمن)
# ============================================================
DICT_AVAILABLE = False
try:
    import enchant
    DICT = enchant.Dict("en_US")
    DICT_AVAILABLE = True
    print("✅ Dictionary loaded successfully!")
except:
    DICT_AVAILABLE = False
    print("⚠️ PyEnchant not installed! Using fallback dictionary.")

def is_valid_word(word):
    if not word or len(word) < 2:
        return False
    word = word.upper()
    if not word.isalpha():
        return False
    if DICT_AVAILABLE:
        try:
            return DICT.check(word.lower())
        except:
            return True
    return True

# ============================================================
# Session Management
# ============================================================
SESSION_FILE = "session.json"

def get_session():
    try:
        if os.path.exists(SESSION_FILE):
            with open(SESSION_FILE, "r") as f:
                data = json.load(f)
                if "user_uuid" in data:
                    return data["user_uuid"]
    except:
        pass
    
    user_uuid = str(uuid.uuid4())
    try:
        with open(SESSION_FILE, "w") as f:
            json.dump({"user_uuid": user_uuid}, f)
    except:
        pass
    return user_uuid

def set_popup_shown():
    try:
        if os.path.exists(SESSION_FILE):
            with open(SESSION_FILE, "r") as f:
                data = json.load(f)
            data["popup_shown"] = True
            with open(SESSION_FILE, "w") as f:
                json.dump(data, f)
    except:
        pass

def is_popup_shown():
    try:
        if os.path.exists(SESSION_FILE):
            with open(SESSION_FILE, "r") as f:
                data = json.load(f)
                return data.get("popup_shown", False)
    except:
        pass
    return False

# ============================================================
# Database (ایمن)
# ============================================================
DB_NAME = "leprecoin_game.db"

def init_database():
    try:
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_uuid TEXT NOT NULL UNIQUE,
                username TEXT,
                email TEXT,
                google_id TEXT,
                wallet_address TEXT,
                coins INTEGER DEFAULT 150,
                avatar_id TEXT DEFAULT 'bald_boy',
                total_words_found INTEGER DEFAULT 0,
                current_level INTEGER DEFAULT 1,
                current_tray INTEGER DEFAULT 1,
                team_name TEXT DEFAULT 'No Team',
                is_registered BOOLEAN DEFAULT 0,
                wins INTEGER DEFAULT 0,
                losses INTEGER DEFAULT 0,
                is_online BOOLEAN DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_login TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS game_state (
                user_uuid TEXT PRIMARY KEY,
                bonus_box TEXT,
                guessed_words TEXT,
                revealed_hint_chars TEXT,
                FOREIGN KEY (user_uuid) REFERENCES users(user_uuid)
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS user_words (
                user_id INTEGER,
                word TEXT,
                found_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id)
            )
        ''')
        
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"❌ Database init error: {e}")
        return False

def get_user_by_uuid(user_uuid):
    try:
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE user_uuid = ?", (user_uuid,))
        user = cursor.fetchone()
        conn.close()
        return user
    except:
        return None

def create_guest_user(user_uuid):
    try:
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO users (user_uuid, coins, avatar_id) VALUES (?, ?, ?)",
            (user_uuid, 150, "bald_boy")
        )
        conn.commit()
        user_id = cursor.lastrowid
        conn.close()
        return user_id
    except:
        return None

def register_user(user_uuid, username, wallet_address):
    try:
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE users SET username = ?, wallet_address = ?, is_registered = 1 WHERE user_uuid = ?",
            (username, wallet_address, user_uuid)
        )
        conn.commit()
        conn.close()
        return True
    except:
        return False

def update_user_coins(user_uuid, coins):
    try:
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute("UPDATE users SET coins = ? WHERE user_uuid = ?", (coins, user_uuid))
        conn.commit()
        conn.close()
    except:
        pass

def update_user_avatar(user_uuid, avatar_id):
    try:
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute("UPDATE users SET avatar_id = ? WHERE user_uuid = ?", (avatar_id, user_uuid))
        conn.commit()
        conn.close()
    except:
        pass

def update_user_progress(user_uuid, level, tray):
    try:
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute("UPDATE users SET current_level = ?, current_tray = ? WHERE user_uuid = ?", (level, tray, user_uuid))
        conn.commit()
        conn.close()
    except:
        pass

def update_user_words_found(user_uuid, total):
    try:
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute("UPDATE users SET total_words_found = ? WHERE user_uuid = ?", (total, user_uuid))
        conn.commit()
        conn.close()
    except:
        pass

def update_user_stats(user_uuid, wins, losses):
    try:
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute("UPDATE users SET wins = ?, losses = ? WHERE user_uuid = ?", (wins, losses, user_uuid))
        conn.commit()
        conn.close()
    except:
        pass

def update_user_online(user_uuid, is_online):
    try:
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute("UPDATE users SET is_online = ? WHERE user_uuid = ?", (is_online, user_uuid))
        conn.commit()
        conn.close()
    except:
        pass

def save_game_state(user_uuid, bonus_box, guessed_words, revealed_hint_chars):
    try:
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute('''
            INSERT OR REPLACE INTO game_state (user_uuid, bonus_box, guessed_words, revealed_hint_chars)
            VALUES (?, ?, ?, ?)
        ''', (user_uuid, json.dumps(bonus_box), json.dumps(guessed_words), json.dumps(revealed_hint_chars)))
        conn.commit()
        conn.close()
    except:
        pass

def load_game_state(user_uuid):
    try:
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute("SELECT bonus_box, guessed_words, revealed_hint_chars FROM game_state WHERE user_uuid = ?", (user_uuid,))
        data = cursor.fetchone()
        conn.close()
        if data:
            return json.loads(data[0]), json.loads(data[1]), json.loads(data[2])
    except:
        pass
    return [], [], {}

def add_user_word(user_uuid, word):
    try:
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM users WHERE user_uuid = ?", (user_uuid,))
        result = cursor.fetchone()
        if result:
            user_id = result[0]
            cursor.execute("INSERT INTO user_words (user_id, word) VALUES (?, ?)", (user_id, word))
            conn.commit()
        conn.close()
    except:
        pass

def get_all_users():
    try:
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute("SELECT id, username, avatar_id, coins, current_level, team_name, wins, losses, is_online, user_uuid FROM users WHERE is_registered = 1")
        users = cursor.fetchall()
        conn.close()
        return users
    except:
        return []

def create_dummy_users():
    dummy_names = [
        "WordMaster", "LeprechaunKing", "CoinHunter", "PuzzlePro", "SpeedGuesser",
        "BrainStorm", "WordWizard", "GoldenTongue", "SwiftMind", "LexiconLord",
        "PuzzleMaster", "WordSage", "CoinCollector", "RiddleKing", "SmartPlayer",
        "QuickThinker", "WordGenius", "LuckyStar", "MindReader", "WordExplorer"
    ]
    
    avatars = ["bald_boy", "bald_girl", "bald_old_man", "bald_old_woman", "king", "queen", "soldier", "baby", "strong_man", "pretty_woman"]
    
    try:
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        
        for i in range(20):
            user_uuid = str(uuid.uuid4())
            username = dummy_names[i % len(dummy_names)] + str(i+1)
            avatar = avatars[i % len(avatars)]
            coins = 400
            level = random.randint(1, 20)
            words = random.randint(10, 50)
            wins = random.randint(0, 10)
            losses = random.randint(0, 5)
            is_online = random.choice([0, 1])
            
            try:
                cursor.execute('''
                    INSERT OR REPLACE INTO users 
                    (user_uuid, username, avatar_id, coins, current_level, total_words_found, wins, losses, is_online, is_registered)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
                ''', (user_uuid, username, avatar, coins, level, words, wins, losses, is_online))
            except:
                pass
        
        conn.commit()
        conn.close()
        print("✅ 20 dummy users created!")
    except:
        pass

# ============================================================
# Word Bank Loader (ایمن)
# ============================================================
def load_word_banks():
    easy_words = ["TEA", "EAT", "AT", "BOOK", "OK", "WATER", "ATE", "HAPPY", "HAP", "SUN", "DOG", "CAT", "FUN", "RUN", "BIG", "SMALL", "TALL", "SHORT", "FAST", "SLOW"]
    medium_words = ["TEACH", "CHEAT", "REACH", "HE", "STAR", "ART", "RAT", "TAR", "TREE", "LEAF", "ROOT", "BRANCH", "FLOWER", "WATER", "LIGHT", "DARK", "SOUND", "VOICE", "MUSIC", "DANCE"]
    hard_words = ["ALGORITHM", "QUANTUM", "ENTROPY", "GRAVITY", "PROTON", "ELECTRON", "NEUTRON", "ENERGY", "MATTER", "FORCE", "MOTION", "VELOCITY", "ACCELERATE", "MOMENTUM", "KINETIC", "POTENTIAL", "NUCLEAR", "MOLECULE", "COMPOUND", "ELEMENT"]
    special_words = ["BIOTECHNOLOGY", "NANOTECHNOLOGY", "ASTROPHYSICS", "NEUROSCIENCE", "QUANTUM", "ENTROPY", "GRAVITY", "PROTON", "ELECTRON", "NEUTRON", "ENERGY", "MATTER", "FORCE", "MOTION", "VELOCITY", "ACCELERATE", "MOMENTUM", "KINETIC", "POTENTIAL"]
    
    try:
        import sys
        import os
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        
        # تلاش برای بارگذاری بانک‌های واقعی
        if os.path.exists('word_banks'):
            from word_banks.bank_easy import get_words as get_easy
            from word_banks.bank_medium import get_words as get_medium
            from word_banks.bank_hard import get_words as get_hard
            from word_banks.bank_special import get_words as get_special
            
            easy_words = get_easy()
            medium_words = get_medium()
            hard_words = [item["word"] if isinstance(item, dict) else item for item in get_hard()]
            special_words = [item["word"] if isinstance(item, dict) else item for item in get_special()]
            
            print(f"✅ Loaded banks from files!")
    except Exception as e:
        print(f"⚠️ Using fallback word banks: {e}")
    
    return easy_words, medium_words, hard_words, special_words

EASY_WORDS, MEDIUM_WORDS, HARD_WORDS, SPECIAL_WORDS = load_word_banks()

# ============================================================
# Word Explanation
# ============================================================
def get_word_explanation(word):
    word = word.upper().strip()
    try:
        if os.path.exists("word_bank_complete.json"):
            import json
            with open("word_bank_complete.json", "r", encoding="utf-8") as f:
                data = json.load(f)
            
            for level_num, trays in data.get("levels", {}).items():
                for tray in trays:
                    word_data = tray.get("word_data", {})
                    if word in word_data:
                        if "explanations" in word_data[word]:
                            return word_data[word]["explanations"].get("en", word)
                        elif "translations" in word_data[word]:
                            return word_data[word]["translations"].get("en", word)
    except:
        pass
    return f"💡 {word}"

# ============================================================
# Generate sub-words
# ============================================================
def generate_sub_words(main_word, min_sub_words=4):
    letters = list(main_word)
    sub_words = []
    valid_common = ["AT", "IN", "ON", "IT", "IS", "AN", "AS", "AM", "HE", "WE", "BE", "BY", "DO", "GO", "HI", "IF", "ME", "MY", "NO", "OF", "OR", "SO", "TO", "UP", "US", "THE", "AND", "FOR", "ARE", "BUT", "NOT", "YOU", "ALL", "CAN", "HAD", "HER", "WAS", "ONE", "OUR", "OUT", "DAY", "GET", "HAS", "HIM", "HOW", "MAN", "NEW", "NOW", "OLD", "SEE", "TWO", "WAY", "BED", "DOG", "CAT", "SUN", "HOT", "SAD", "BIG", "COW", "PIG", "HEN", "FOX", "OWL", "RAT", "BAT", "HAT", "CAP", "MAP"]
    
    for i in range(len(letters)):
        for j in range(i+1, len(letters)):
            w = letters[i] + letters[j]
            if w in valid_common and w != main_word and w not in sub_words:
                sub_words.append(w)
    
    for i in range(len(letters)):
        for j in range(i+1, len(letters)):
            for k in range(j+1, len(letters)):
                w = letters[i] + letters[j] + letters[k]
                if w in valid_common and w != main_word and w not in sub_words:
                    sub_words.append(w)
    
    if len(sub_words) < min_sub_words:
        for i in range(len(letters)):
            for j in range(i+1, len(letters)):
                for k in range(j+1, len(letters)):
                    for l in range(k+1, len(letters)):
                        if len(letters) >= 4:
                            w = letters[i] + letters[j] + letters[k] + letters[l]
                            if is_valid_word(w) and w != main_word and w not in sub_words:
                                sub_words.append(w)
                                if len(sub_words) >= min_sub_words:
                                    break
                    if len(sub_words) >= min_sub_words:
                        break
                if len(sub_words) >= min_sub_words:
                    break
            if len(sub_words) >= min_sub_words:
                break
    
    return sub_words[:6]

# ============================================================
# Game Controller (با مدیریت خطا)
# ============================================================
class GameController:
    def __init__(self, user_uuid):
        self.user_uuid = user_uuid
        self.user_id = None
        self.coins = 150
        self.current_level = 1
        self.current_tray = 1
        self.guessed_words = []
        self.all_found_words = []
        self.revealed_hint_chars = {}
        self.letters = ["T", "E", "A"]
        self.main_words = ["TEA", "EAT", "AT"]
        self.bonus_box = []
        self.tray_completed = False
        self.total_words_found = 0
        self.avatar_id = "bald_boy"
        self.username = "Guest"
        self.wallet_address = ""
        self.team_name = "No Team"
        self.is_registered = False
        self.wins = 0
        self.losses = 0
        
        self._load_user_data()
        self._load_game_state()
        self._load_tray()
    
    def _load_user_data(self):
        try:
            user = get_user_by_uuid(self.user_uuid)
            if user:
                self.user_id = user[0]
                self.username = user[2] or "Guest"
                self.wallet_address = user[5] or ""
                self.avatar_id = user[7] or "bald_boy"
                self.team_name = user[11] or "No Team"
                self.is_registered = user[12] == 1
                self.wins = user[13] if len(user) > 13 else 0
                self.losses = user[14] if len(user) > 14 else 0
                self.coins = int(user[6]) if user[6] and str(user[6]).isdigit() else 150
                self.total_words_found = int(user[8]) if user[8] and str(user[8]).isdigit() else 0
                self.current_level = int(user[9]) if user[9] and str(user[9]).isdigit() else 1
                self.current_tray = int(user[10]) if user[10] and str(user[10]).isdigit() else 1
            else:
                user_id = create_guest_user(self.user_uuid)
                if user_id:
                    self.user_id = user_id
        except Exception as e:
            print(f"❌ Error loading user data: {e}")
            # استفاده از مقادیر پیش‌فرض
            pass
    
    def _load_game_state(self):
        try:
            bonus_box, guessed_words, revealed_hint_chars = load_game_state(self.user_uuid)
            self.bonus_box = bonus_box
            self.guessed_words = guessed_words
            self.revealed_hint_chars = revealed_hint_chars
        except:
            self.bonus_box = []
            self.guessed_words = []
            self.revealed_hint_chars = {}
    
    def _save_game_state(self):
        try:
            save_game_state(self.user_uuid, self.bonus_box, self.guessed_words, self.revealed_hint_chars)
        except:
            pass
    
    def _load_tray(self):
        try:
            word = self._get_word_for_tray(self.current_level, self.current_tray)
            
            if word:
                sub_words = generate_sub_words(word, min_sub_words=4)
                self.main_words = [word] + sub_words[:4]
                self.letters = list(word)
                random.shuffle(self.letters)
            else:
                self.letters = ["T", "E", "A"]
                self.main_words = ["TEA", "EAT", "AT"]
            
            self.guessed_words = []
            self.revealed_hint_chars = {}
            self.tray_completed = False
        except Exception as e:
            print(f"❌ Error loading tray: {e}")
            self.letters = ["T", "E", "A"]
            self.main_words = ["TEA", "EAT", "AT"]
    
    def _get_word_for_tray(self, level, tray):
        tray_index = (level - 1) * 20 + (tray - 1)
        total_trays = 64 * 20
        
        if tray_index >= total_trays:
            return None
        
        try:
            if level <= 3:
                if level == 1 and tray >= 4 and tray <= 20:
                    if tray_index % 3 == 0:
                        return self._get_random_word(MEDIUM_WORDS)
                    else:
                        return self._get_random_word(EASY_WORDS)
                else:
                    return self._get_random_word(EASY_WORDS)
                    
            elif level <= 10:
                if tray_index % 3 == 0:
                    return self._get_random_word(HARD_WORDS)
                elif tray_index % 3 == 1:
                    return self._get_random_word(MEDIUM_WORDS)
                else:
                    return self._get_random_word(EASY_WORDS)
                    
            elif level <= 20:
                if tray_index % 3 == 0:
                    return self._get_random_word(SPECIAL_WORDS)
                elif tray_index % 3 == 1:
                    return self._get_random_word(HARD_WORDS)
                else:
                    return self._get_random_word(MEDIUM_WORDS)
                    
            else:
                categories = [EASY_WORDS, MEDIUM_WORDS, HARD_WORDS, SPECIAL_WORDS]
                cat_index = tray_index % 4
                return self._get_random_word(categories[cat_index])
        except:
            return "TEA"
    
    def _get_random_word(self, word_list):
        if not word_list:
            return "TEA"
        import hashlib
        seed = f"{self.current_level}_{self.current_tray}"
        hash_val = int(hashlib.md5(seed.encode()).hexdigest(), 16)
        return word_list[hash_val % len(word_list)]
    
    def get_hint_chars(self, word):
        return self.revealed_hint_chars.get(word, [])
    
    def check_guess(self, guess):
        guess = guess.upper().strip()
        
        if not is_valid_word(guess):
            return {"status": "WRONG", "message": f"❌ '{guess}' is not a valid word!"}
        
        if guess in self.guessed_words:
            return {"status": "ALREADY_FOUND", "message": f"'{guess}' already found!"}
        
        if guess in self.main_words:
            self.guessed_words.append(guess)
            self.all_found_words.append(guess)
            self.coins += len(guess) * 2
            self.total_words_found += 1
            
            add_user_word(self.user_uuid, guess)
            update_user_words_found(self.user_uuid, self.total_words_found)
            update_user_coins(self.user_uuid, self.coins)
            self._save_game_state()
            
            if len(self.guessed_words) == len(self.main_words) and not self.tray_completed:
                self.tray_completed = True
                self.coins += 10
                update_user_coins(self.user_uuid, self.coins)
                self._save_game_state()
                return {"status": "TRAY_COMPLETED", "message": f"🎉 Tray Complete! +10 bonus coins!", "word": guess}
            
            return {"status": "CORRECT", "message": f"✅ '{guess}' found! +{len(guess)*2} coins", "word": guess}
        
        if guess in self.bonus_box:
            return {"status": "ALREADY_IN_BONUS", "message": f"'{guess}' already in Bonus Box!"}
        
        if is_valid_word(guess):
            self.bonus_box.append(guess)
            self.all_found_words.append(guess)
            self._save_game_state()
            
            if len(self.bonus_box) >= 10:
                self.coins += 5
                self.bonus_box = []
                update_user_coins(self.user_uuid, self.coins)
                self._save_game_state()
                return {"status": "BONUS_REWARD", "message": "🎁 Bonus Box FULL! +5 coins!"}
            else:
                return {"status": "BONUS_ADDED", "message": f"📦 '{guess}' added to Bonus Box! ({len(self.bonus_box)}/10)"}
        
        return {"status": "WRONG", "message": f"❌ '{guess}' is not a valid word!"}
    
    def use_hint(self):
        if self.coins < 5:
            return {"status": "FAIL", "message": "Not enough coins! (need 5)"}
        
        remaining = [w for w in self.main_words if w not in self.guessed_words]
        if not remaining:
            return {"status": "FAIL", "message": "No unsolved words!"}
        
        target = remaining[0]
        if target not in self.revealed_hint_chars:
            self.revealed_hint_chars[target] = []
        
        for idx, char in enumerate(target):
            if idx not in self.revealed_hint_chars[target]:
                self.revealed_hint_chars[target].append(idx)
                self.coins -= 5
                update_user_coins(self.user_uuid, self.coins)
                self._save_game_state()
                
                if len(self.revealed_hint_chars[target]) == len(target):
                    if target not in self.guessed_words:
                        self.guessed_words.append(target)
                        self.all_found_words.append(target)
                        self.coins += len(target) * 2
                        self.total_words_found += 1
                        add_user_word(self.user_uuid, target)
                        update_user_words_found(self.user_uuid, self.total_words_found)
                        update_user_coins(self.user_uuid, self.coins)
                        self._save_game_state()
                        
                        if len(self.guessed_words) == len(self.main_words) and not self.tray_completed:
                            self.tray_completed = True
                            self.coins += 10
                            update_user_coins(self.user_uuid, self.coins)
                            self._save_game_state()
                            return {"status": "TRAY_COMPLETED", "message": f"🎉 Tray Complete! +10 bonus coins!", "word": target}
                
                return {"status": "SUCCESS", "message": f"💡 Hint revealed: {char}", "word": target}
        
        return {"status": "FAIL", "message": "All letters already revealed!"}
    
    def use_shuffle(self):
        if self.coins < 1:
            return {"status": "FAIL", "message": "Not enough coins! (need 1)"}
        
        self.coins -= 1
        random.shuffle(self.letters)
        update_user_coins(self.user_uuid, self.coins)
        self._save_game_state()
        return {"status": "SUCCESS", "message": "🔄 Letters shuffled!"}
    
    def next_tray(self):
        self.current_tray += 1
        if self.current_tray > 20:
            self.current_tray = 1
            self.current_level += 1
        
        self.guessed_words = []
        self.revealed_hint_chars = {}
        self.tray_completed = False
        
        self._load_tray()
        self._save_game_state()
        update_user_progress(self.user_uuid, self.current_level, self.current_tray)
        
        return {"status": "SUCCESS", "message": "Next tray loaded!"}
    
    def watch_ad_rewarded(self):
        self.coins = int(self.coins) + 20
        update_user_coins(self.user_uuid, self.coins)
        self._save_game_state()
        return {"status": "SUCCESS", "message": "📺 +20 coins for watching rewarded ad!"}
    
    def watch_ad_interstitial(self):
        self.coins = int(self.coins) + 10
        update_user_coins(self.user_uuid, self.coins)
        self._save_game_state()
        return {"status": "SUCCESS", "message": "📱 +10 coins for watching interstitial ad!"}
    
    def register_user(self, username, wallet_address):
        success = register_user(self.user_uuid, username, wallet_address)
        if success:
            self.username = username
            self.wallet_address = wallet_address
            self.is_registered = True
            user = get_user_by_uuid(self.user_uuid)
            if user:
                try:
                    self.coins = int(user[6]) if user[6] and str(user[6]).isdigit() else 150
                except:
                    self.coins = 150
                try:
                    self.total_words_found = int(user[8]) if user[8] and str(user[8]).isdigit() else 0
                except:
                    self.total_words_found = 0
        return success


# ============================================================
# Clover Wheel Widget (با تصویر ایمن)
# ============================================================
class CloverWheel(RelativeLayout):
    def __init__(self, letters, on_word_drawn=None, **kwargs):
        super(CloverWheel, self).__init__(**kwargs)
        self.letters = letters
        self.on_word_drawn = on_word_drawn
        self.letter_buttons = {}
        self.selected_indices = []
        self.swipe_indices = []
        self.is_drawing = False
        
        # بارگذاری ایمن تصویر چرخ شبدری
        try:
            wheel_img = safe_load_image('image/game/clover_wheel.png')
            if isinstance(wheel_img, Image):
                self.wheel_image = wheel_img
                self.wheel_image.size_hint = (1, 1)
                self.wheel_image.pos_hint = {'center_x': 0.5, 'center_y': 0.5}
                self.wheel_image.allow_stretch = True
                self.wheel_image.keep_ratio = True
            else:
                self.wheel_image = Label(text="🍀", font_size=dp(80), color=(0, 1, 0.4, 1))
                self.wheel_image.size_hint = (1, 1)
                self.wheel_image.pos_hint = {'center_x': 0.5, 'center_y': 0.5}
        except:
            self.wheel_image = Label(text="🍀", font_size=dp(80), color=(0, 1, 0.4, 1))
            self.wheel_image.size_hint = (1, 1)
            self.wheel_image.pos_hint = {'center_x': 0.5, 'center_y': 0.5}
        
        self.add_widget(self.wheel_image)
        self._setup_letters()
        self.bind(size=self._update_letters)
    
    def _setup_letters(self):
        """تنظیم حروف روی چرخ شبدری"""
        # پاک کردن دکمه‌های قبلی
        for child in self.children[:]:
            if isinstance(child, Button):
                self.remove_widget(child)
        self.letter_buttons.clear()
        
        num_letters = len(self.letters)
        if num_letters == 0:
            return
        
        w, h = self.size
        center_x = w / 2
        center_y = h / 2
        radius = min(w, h) * 0.32
        letter_size = min(dp(50), radius * 0.6)
        font_size = min(dp(22), radius * 0.35)
        
        for i, letter in enumerate(self.letters):
            angle = (2 * math.pi / num_letters) * i - math.pi / 2
            x = center_x + radius * math.cos(angle) - letter_size / 2
            y = center_y + radius * math.sin(angle) - letter_size / 2
            
            is_selected = i in self.selected_indices
            
            # بارگذاری تصویر برگ شبدر
            try:
                btn = Button(
                    text=letter,
                    font_size=font_size,
                    font_name=FONT_BOLD,
                    size_hint=(None, None),
                    size=(letter_size, letter_size),
                    pos=(x, y),
                    background_normal='image/game/clover_leaf.png' if os.path.exists(safe_resource_path('image/game/clover_leaf.png')) else '',
                    background_color=(1, 1, 1, 0.9) if not is_selected else (1, 0.8, 0.2, 1),
                    color=(0, 0.3, 0, 1) if not is_selected else (1, 0.8, 0, 1),
                    halign='center',
                    valign='middle'
                )
            except:
                btn = Button(
                    text=letter,
                    font_size=font_size,
                    font_name=FONT_BOLD,
                    size_hint=(None, None),
                    size=(letter_size, letter_size),
                    pos=(x, y),
                    background_color=(0.2, 0.6, 0.2, 0.9) if not is_selected else (1, 0.8, 0.2, 1),
                    color=(1, 1, 1, 1) if not is_selected else (1, 0.8, 0, 1),
                    halign='center',
                    valign='middle'
                )
            
            self.add_widget(btn)
            self.letter_buttons[i] = (x + letter_size/2, y + letter_size/2)
    
    def _update_letters(self, *args):
        self._setup_letters()
    
    def on_touch_down(self, touch):
        if self.collide_point(*touch.pos) and len(self.letters) > 0:
            self.is_drawing = True
            self.swipe_indices = []
            self.selected_indices = []
            self._check_collision(touch.pos)
            return True
        return super(CloverWheel, self).on_touch_down(touch)
    
    def on_touch_move(self, touch):
        if self.is_drawing and self.collide_point(*touch.pos):
            self._check_collision(touch.pos)
            self._redraw_lines(touch.pos)
            return True
        return super(CloverWheel, self).on_touch_move(touch)
    
    def on_touch_up(self, touch):
        if self.is_drawing:
            self.is_drawing = False
            self.canvas.remove_group('swipe_lines')
            
            if len(self.swipe_indices) >= 2:
                word = "".join([self.letters[i] for i in self.swipe_indices])
                if self.on_word_drawn:
                    self.on_word_drawn(word)
            
            self.swipe_indices = []
            self.selected_indices = []
            self._setup_letters()
            return True
        return super(CloverWheel, self).on_touch_up(touch)
    
    def _check_collision(self, pos):
        local_pos = self.to_widget(*pos)
        for idx, center in self.letter_buttons.items():
            dist = math.sqrt((local_pos[0] - center[0])**2 + (local_pos[1] - center[1])**2)
            if dist < dp(35) and idx not in self.swipe_indices:
                self.swipe_indices.append(idx)
                if idx not in self.selected_indices:
                    self.selected_indices.append(idx)
                self._setup_letters()
                break
    
    def _redraw_lines(self, current_pos):
        self.canvas.remove_group('swipe_lines')
        if len(self.swipe_indices) < 2:
            return
        
        local_mouse = self.to_widget(*current_pos)
        with self.canvas:
            Color(1, 0.75, 0, 1, group='swipe_lines')
            points = []
            for idx in self.swipe_indices:
                points.extend(self.letter_buttons[idx])
            points.extend(local_mouse)
            if len(points) >= 4:
                Line(points=points, width=3, group='swipe_lines')
    
    def update_letters(self, new_letters):
        self.letters = new_letters
        self.selected_indices = []
        self.swipe_indices = []
        self._setup_letters()


# ============================================================
# Avatar Helpers (ایمن)
# ============================================================
AVATAR_FOLDER = "avatars"

def save_custom_avatar(user_uuid, image_path):
    try:
        from PIL import Image
        os.makedirs(AVATAR_FOLDER, exist_ok=True)
        img = Image.open(image_path)
        if img.mode == 'RGBA':
            img = img.convert('RGB')
        img = img.resize((150, 150))
        save_path = os.path.join(AVATAR_FOLDER, f"custom_{user_uuid}.png")
        img.save(save_path, 'PNG')
        return f"custom_{user_uuid}"
    except Exception as e:
        print(f"❌ Error saving avatar: {e}")
        return None

def get_avatar_image_path(avatar_id, user_uuid):
    if avatar_id and avatar_id.startswith("custom_"):
        path = os.path.join(AVATAR_FOLDER, f"{avatar_id}.png")
        if os.path.exists(path):
            return path
    avatar_path = safe_resource_path(f"image/avatars/{avatar_id}.png")
    if os.path.exists(avatar_path):
        return avatar_path
    return None

def get_avatar_image(avatar_id, user_uuid):
    """دریافت تصویر آواتار با fallback"""
    path = get_avatar_image_path(avatar_id, user_uuid)
    if path:
        try:
            return Image(source=path, allow_stretch=True, keep_ratio=True)
        except:
            pass
    return Label(text="👤", font_size=dp(30), color=(1, 1, 1, 1))

def delete_custom_avatar(user_uuid):
    try:
        path = os.path.join(AVATAR_FOLDER, f"custom_{user_uuid}.png")
        if os.path.exists(path):
            os.remove(path)
            return True
    except:
        pass
    return False


# ============================================================
# LepreCoinApp (با نمایش خطاها به کاربر)
# ============================================================
class LepreCoinApp(App):
    def __init__(self, **kwargs):
        super(LepreCoinApp, self).__init__(**kwargs)
        try:
            init_database()
            create_dummy_users()
        except Exception as e:
            print(f"❌ Database init error: {e}")
        
        self.user_uuid = get_session()
        self.controller = GameController(self.user_uuid)
        self.ads = None
        self.admob_loaded = False
        self._setup_admob()
    
    def _setup_admob(self):
        try:
            if ADMOB_AVAILABLE:
                self.ads = KivMob(ADMOB_APP_ID)
                if hasattr(self.ads, 'new_interstitial'):
                    self.ads.new_interstitial(ADMOB_INTERSTITIAL_ID)
                if hasattr(self.ads, 'new_rewarded_video'):
                    self.ads.new_rewarded_video(ADMOB_REWARDED_ID)
                if hasattr(self.ads, 'new_banner'):
                    self.ads.new_banner(ADMOB_BANNER_ID)
                
                if hasattr(self.ads, 'load_interstitial'):
                    self.ads.load_interstitial()
                if hasattr(self.ads, 'load_rewarded_video'):
                    self.ads.load_rewarded_video()
                if hasattr(self.ads, 'load_banner'):
                    self.ads.load_banner()
                
                self.admob_loaded = True
                print("✅ AdMob initialized successfully!")
            else:
                print("⚠️ KivMob not available. Ads will be simulated.")
        except Exception as e:
            print(f"⚠️ AdMob initialization error: {e}")
            self.admob_loaded = False
    
    def show_rewarded_ad(self, callback=None):
        try:
            if self.admob_loaded and self.ads and hasattr(self.ads, 'show_rewarded_video'):
                if hasattr(self.ads, 'rewarded_video') and hasattr(self.ads.rewarded_video, 'on_complete'):
                    def on_reward_complete():
                        print("✅ Rewarded ad completed!")
                        if callback:
                            callback()
                    self.ads.rewarded_video.on_complete = on_reward_complete
                self.ads.show_rewarded_video()
                return True
        except Exception as e:
            print(f"⚠️ Error showing rewarded ad: {e}")
        return False
    
    def show_interstitial_ad(self):
        try:
            if self.admob_loaded and self.ads and hasattr(self.ads, 'show_interstitial'):
                self.ads.show_interstitial()
                return True
        except Exception as e:
            print(f"⚠️ Error showing interstitial ad: {e}")
        return False
    
    def show_banner_ad(self, show=True):
        try:
            if self.admob_loaded and self.ads and hasattr(self.ads, 'show_banner'):
                if show:
                    self.ads.show_banner()
                else:
                    self.ads.hide_banner()
                return True
        except Exception as e:
            print(f"⚠️ Error toggling banner ad: {e}")
        return False
    
    def build(self):
        self.title = "LepreCoin"
        self.root = BoxLayout(orientation='vertical')
        self.show_welcome()
        return self.root
    
    def show_welcome(self):
        self.root.clear_widgets()
        self.root.add_widget(WelcomeScreen(
            controller=self.controller,
            on_register=self.show_register,
            on_skip=self.show_game_world,
            app=self
        ))
    
    def show_register(self):
        self.root.clear_widgets()
        self.root.add_widget(RegisterScreen(
            controller=self.controller,
            on_success=self.show_game_world,
            on_back=self.show_welcome
        ))
    
    def show_game_world(self, *args):
        self.root.clear_widgets()
        self.root.add_widget(GameWorldScreen(
            controller=self.controller,
            on_menu=self.show_menu,
            on_profile=self.show_profile,
            app=self
        ))
    
    def show_menu(self, *args):
        self.root.clear_widgets()
        self.root.add_widget(MenuScreen(
            controller=self.controller,
            on_close=self.show_game_world,
            on_register=self.show_register,
            app=self
        ))
    
    def show_profile(self):
        self.root.clear_widgets()
        self.root.add_widget(ProfileScreen(
            controller=self.controller,
            on_back=self.show_game_world
        ))
    
    def _show_popup(self, title, message):
        try:
            content = BoxLayout(orientation='vertical', padding=10, spacing=10)
            content.add_widget(Label(text=message, font_name=FONT_REGULAR))
            btn = Button(text="OK", font_name=FONT_REGULAR, size_hint_y=None, height=40)
            popup = Popup(title=title, content=content, size_hint=(0.7, 0.3))
            btn.bind(on_press=popup.dismiss)
            content.add_widget(btn)
            popup.open()
        except:
            print(f"Popup: {title} - {message}")


# ============================================================
# Welcome Screen (با مدیریت خطا و دسترسی)
# ============================================================
class WelcomeScreen(BoxLayout):
    def __init__(self, controller, on_register, on_skip, app=None, **kwargs):
        super(WelcomeScreen, self).__init__(**kwargs)
        self.orientation = 'vertical'
        self.padding = dp(20)
        self.spacing = dp(10)
        self.controller = controller
        self.on_register = on_register
        self.on_skip = on_skip
        self.app = app
        
        with self.canvas.before:
            Color(0.05, 0.12, 0.06, 1)
            self.bg = Rectangle(size=self.size, pos=self.pos)
        self.bind(size=self._update_bg, pos=self._update_bg)
        
        # بارگذاری ایمن بک‌گراند
        try:
            bg = safe_load_image('image/backgrounds/bg_login.png')
            if isinstance(bg, Image):
                self.add_widget(bg)
        except:
            pass
        
        # لایه رویی
        overlay = BoxLayout(orientation='vertical', padding=dp(20), spacing=dp(10))
        
        # لوگو
        try:
            logo = safe_load_image('image/branding/logo.png')
            if isinstance(logo, Image):
                logo.size_hint = (0.6, 0.2)
                logo.pos_hint = {'center_x': 0.5}
                overlay.add_widget(logo)
            else:
                title = Label(text="🍀 LEPRECOIN", font_name=FONT_BOLD, font_size=dp(36), color=(1, 0.85, 0, 1), size_hint_y=0.12)
                overlay.add_widget(title)
        except:
            title = Label(text="🍀 LEPRECOIN", font_name=FONT_BOLD, font_size=dp(36), color=(1, 0.85, 0, 1), size_hint_y=0.12)
            overlay.add_widget(title)
        
        welcome_text = "🔮 Welcome to the legendary Leprechaun Wealth Realm!\n\nFind hidden words, earn coins,\nand unlock the treasure of wisdom.\n\n✨ Are you ready to begin?"
        msg = Label(
            text=welcome_text,
            font_name=FONT_REGULAR,
            font_size=dp(14),
            size_hint_y=0.25,
            text_size=(Window.width * 0.7, None),
            halign='center',
            valign='middle',
            color=(1, 1, 1, 1),
            bold=True
        )
        msg.bind(size=msg.setter('text_size'))
        overlay.add_widget(msg)
        
        btn_row = BoxLayout(orientation='horizontal', size_hint_y=0.12, spacing=dp(10))
        
        btn_skip = Button(
            text="Play as Guest",
            font_size=dp(14),
            background_color=(0.2, 0.3, 0.2, 1),
            color=(1, 1, 1, 1)
        )
        btn_skip.bind(on_press=self._skip)
        btn_row.add_widget(btn_skip)
        
        btn_register = Button(
            text="Create Account",
            font_name=FONT_BOLD,
            font_size=dp(14),
            background_color=(0.2, 0.5, 0.1, 1),
            color=(1, 0.85, 0, 1)
        )
        btn_register.bind(on_press=self._go_to_register)
        btn_row.add_widget(btn_register)
        
        overlay.add_widget(btn_row)
        
        # لپرکان
        try:
            leprechaun = safe_load_image('image/characters/avatar_guest.png')
            if isinstance(leprechaun, Image):
                leprechaun.size_hint = (0.3, 0.25)
                leprechaun.pos_hint = {'center_x': 0.5}
                overlay.add_widget(leprechaun)
        except:
            pass
        
        self.add_widget(overlay)
    
    def _update_bg(self, *args):
        if hasattr(self, 'bg'):
            self.bg.size = self.size
            self.bg.pos = self.pos
    
    def _skip(self, instance):
        self.on_skip()
    
    def _go_to_register(self, instance):
        self.on_register()


# ============================================================
# Register Screen (با مدیریت خطا)
# ============================================================
class RegisterScreen(BoxLayout):
    def __init__(self, controller, on_success, on_back, **kwargs):
        super(RegisterScreen, self).__init__(**kwargs)
        self.orientation = 'vertical'
        self.padding = dp(20)
        self.spacing = dp(12)
        self.controller = controller
        self.on_success = on_success
        self.on_back = on_back
        self.selected_avatar = "bald_boy"
        
        with self.canvas.before:
            Color(0.05, 0.12, 0.06, 1)
            self.bg = Rectangle(size=self.size, pos=self.pos)
        self.bind(size=self._update_bg, pos=self._update_bg)
        
        overlay = BoxLayout(orientation='vertical', padding=dp(20), spacing=dp(10))
        
        title = Label(text="📝 Create Account", font_name=FONT_BOLD, font_size=dp(24), color=(1, 0.85, 0, 1), size_hint_y=0.08)
        overlay.add_widget(title)
        
        self.username_input = TextInput(
            hint_text="Username (Required)",
            multiline=False,
            font_size=dp(14),
            size_hint_y=None,
            height=dp(45),
            background_color=(0.15, 0.25, 0.15, 1),
            foreground_color=(1, 1, 1, 1)
        )
        overlay.add_widget(self.username_input)
        
        self.wallet_input = TextInput(
            hint_text="Wallet Address (Optional)",
            multiline=False,
            font_size=dp(14),
            size_hint_y=None,
            height=dp(45),
            background_color=(0.15, 0.25, 0.15, 1),
            foreground_color=(1, 1, 1, 1)
        )
        overlay.add_widget(self.wallet_input)
        
        avatar_label = Label(text="Select Avatar (Free):", font_size=dp(14), color=(1, 1, 1, 1), size_hint_y=0.05)
        overlay.add_widget(avatar_label)
        
        avatar_grid = GridLayout(cols=4, spacing=dp(5), size_hint_y=0.25)
        for av in FREE_AVATARS:
            btn = Button(
                size_hint_y=None,
                height=dp(50),
                background_normal=f'image/avatars/{av["id"]}.png' if os.path.exists(safe_resource_path(f'image/avatars/{av["id"]}.png')) else '',
                background_color=(1, 1, 1, 1) if av["id"] == self.selected_avatar else (0.5, 0.5, 0.5, 0.7),
                border=(0, 0, 0, 0),
                text=av["name"][:3] if not os.path.exists(safe_resource_path(f'image/avatars/{av["id"]}.png')) else ''
            )
            btn.bind(on_press=lambda x, aid=av["id"]: self._select_avatar(aid))
            avatar_grid.add_widget(btn)
        overlay.add_widget(avatar_grid)
        
        btn_row = BoxLayout(orientation='horizontal', size_hint_y=0.08, spacing=dp(10))
        btn_back = Button(text="← Back", font_size=dp(14), background_color=(0.3, 0.3, 0.3, 1), color=(1, 1, 1, 1))
        btn_back.bind(on_press=self._go_back)
        btn_row.add_widget(btn_back)
        btn_register = Button(text="✅ Register", font_size=dp(14), background_color=(0.2, 0.5, 0.1, 1), color=(1, 0.85, 0, 1))
        btn_register.bind(on_press=self._register)
        btn_row.add_widget(btn_register)
        overlay.add_widget(btn_row)
        
        self.add_widget(overlay)
    
    def _update_bg(self, *args):
        if hasattr(self, 'bg'):
            self.bg.size = self.size
            self.bg.pos = self.pos
    
    def _select_avatar(self, avatar_id):
        self.selected_avatar = avatar_id
        for child in self.children:
            if isinstance(child, BoxLayout):
                for grid in child.children:
                    if isinstance(grid, GridLayout):
                        for btn in grid.children:
                            if hasattr(btn, 'background_normal'):
                                if btn.background_normal == f'image/avatars/{avatar_id}.png':
                                    btn.background_color = (1, 1, 1, 1)
                                else:
                                    btn.background_color = (0.5, 0.5, 0.5, 0.7)
    
    def _go_back(self, instance):
        self.on_back()
    
    def _register(self, instance):
        username = self.username_input.text.strip()
        wallet = self.wallet_input.text.strip()
        
        if not username:
            self._show_popup("Error", "Username is required!")
            return
        
        conn = sqlite3.connect(DB_NAME)
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM users WHERE username = ? AND is_registered = 1", (username,))
        if cursor.fetchone():
            conn.close()
            self._show_popup("Error", "Username already taken!")
            return
        conn.close()
        
        update_user_avatar(self.controller.user_uuid, self.selected_avatar)
        self.controller.avatar_id = self.selected_avatar
        
        success = self.controller.register_user(username, wallet)
        if success:
            self._show_popup("Success", f"Welcome {username}!")
            self.on_success()
        else:
            self._show_popup("Error", "Something went wrong!")
    
    def _show_popup(self, title, message):
        try:
            content = BoxLayout(orientation='vertical', padding=10, spacing=10)
            content.add_widget(Label(text=message, font_name=FONT_REGULAR))
            btn = Button(text="OK", font_name=FONT_REGULAR, size_hint_y=None, height=40)
            popup = Popup(title=title, content=content, size_hint=(0.7, 0.3))
            btn.bind(on_press=popup.dismiss)
            content.add_widget(btn)
            popup.open()
        except:
            pass


# ============================================================
# Game World Screen (با مدیریت کامل خطاها)
# ============================================================
class GameWorldScreen(BoxLayout):
    def __init__(self, controller, on_menu, on_profile, app=None, **kwargs):
        super(GameWorldScreen, self).__init__(**kwargs)
        self.orientation = 'vertical'
        self.padding = dp(10)
        self.spacing = dp(5)
        self.controller = controller
        self.on_menu = on_menu
        self.on_profile = on_profile
        self.app = app
        self.ad_popup = None
        self.ad_progress = 0
        self.progress_fill = None
        self.banner_shown = False
        self.stage_counter = 0
        self.INTERSTITIAL_INTERVAL = 4
        
        # بک‌گراند با try/except
        try:
            bg = safe_load_image('image/backgrounds/bg_game.png')
            if isinstance(bg, Image):
                self.add_widget(bg)
        except:
            pass
        
        # لایه رویی
        overlay = BoxLayout(orientation='vertical', padding=dp(10), spacing=dp(5))
        
        if not controller.is_registered and not is_popup_shown():
            Clock.schedule_once(self._show_register_popup, 0.5)
        
        self._build_ui(overlay)
        self._update_ui()
        self.add_widget(overlay)
    
    def _show_register_popup(self, dt):
        if not is_popup_shown():
            try:
                content = BoxLayout(orientation='vertical', padding=10, spacing=10)
                info = Label(text="If you want to use all game features (save progress, join leagues, compete with others), please register!", font_size=dp(14), color=(1, 1, 1, 1), halign='center', size_hint_y=0.6)
                info.bind(size=info.setter('text_size'))
                content.add_widget(info)
                
                btn_row = BoxLayout(orientation='horizontal', size_hint_y=0.3, spacing=10)
                btn_skip = Button(text="Skip", background_color=(0.3, 0.3, 0.3, 1))
                btn_skip.bind(on_press=lambda x: [popup.dismiss(), set_popup_shown()])
                btn_row.add_widget(btn_skip)
                btn_register = Button(text="Register", background_color=(0.2, 0.5, 0.1, 1), color=(1, 0.85, 0, 1))
                btn_register.bind(on_press=lambda x: [popup.dismiss(), set_popup_shown(), self._go_to_register()])
                btn_row.add_widget(btn_register)
                content.add_widget(btn_row)
                
                popup = Popup(title="👋 Welcome!", content=content, size_hint=(0.85, 0.4))
                popup.open()
            except:
                pass
    
    def _go_to_register(self):
        self.on_menu("register")
    
    def _build_ui(self, overlay):
        # نوار بالا
        top_bar = BoxLayout(size_hint_y=0.08, spacing=dp(5))
        
        btn_menu = Button(
            text="☰",
            font_size=dp(16),
            size_hint_x=0.15,
            background_color=(0.2, 0.3, 0.5, 1),
            color=(1, 1, 1, 1)
        )
        btn_menu.bind(on_press=self.on_menu)
        top_bar.add_widget(btn_menu)
        
        self.coins_label = Label(
            text=f"🪙 {self.controller.coins}",
            font_name=FONT_BOLD,
            font_size=dp(16),
            color=(1, 0.8, 0, 1),
            halign='center',
            size_hint_x=0.4
        )
        top_bar.add_widget(self.coins_label)
        
        right_box = BoxLayout(orientation='vertical', size_hint_x=0.35, spacing=dp(1))
        
        # آواتار کاربر با بارگذاری ایمن
        avatar_img = get_avatar_image(self.controller.avatar_id, self.controller.user_uuid)
        if isinstance(avatar_img, Image):
            self.avatar_image = avatar_img
            self.avatar_image.size_hint = (None, None)
            self.avatar_image.size = (dp(30), dp(30))
            self.avatar_image.pos_hint = {'center_x': 0.5}
            right_box.add_widget(self.avatar_image)
        else:
            self.avatar_image = Label(text="👤", font_size=dp(20), color=(1, 1, 1, 1))
            right_box.add_widget(self.avatar_image)
        
        self.username_label = Label(
            text=f"{self.controller.username}",
            font_size=dp(10),
            color=(1, 1, 1, 1),
            halign='center'
        )
        right_box.add_widget(self.username_label)
        right_box.bind(on_touch_down=self._on_avatar_click)
        top_bar.add_widget(right_box)
        overlay.add_widget(top_bar)
        
        # اطلاعات مرحله
        self.level_label = Label(
            text=f"Stage {self.controller.current_level} - Tray {self.controller.current_tray}/20",
            font_size=dp(16),
            font_name=FONT_BOLD,
            size_hint_y=0.05,
            color=(1, 0.6, 0, 1)
        )
        overlay.add_widget(self.level_label)
        
        self.stage_counter_label = Label(
            text=f"⏳ Next interstitial: {self.INTERSTITIAL_INTERVAL - self.stage_counter} stages",
            font_size=dp(10),
            color=(0.6, 0.2, 0.8, 0.7),
            size_hint_y=0.03,
            halign='center'
        )
        overlay.add_widget(self.stage_counter_label)
        
        # کلمات پیدا شده
        word_rows = BoxLayout(orientation='vertical', size_hint_y=0.15, spacing=dp(2))
        self.words_grid = GridLayout(cols=1, spacing=dp(2), size_hint_y=None)
        self.words_grid.bind(minimum_height=self.words_grid.setter('height'))
        word_rows.add_widget(self.words_grid)
        overlay.add_widget(word_rows)
        
        self.msg_label = Label(
            text="🔮 Swipe to draw a word!",
            font_size=dp(14),
            color=(1, 1, 1, 1),
            size_hint_y=0.05
        )
        overlay.add_widget(self.msg_label)
        
        self.explanation_label = Label(
            text="",
            font_size=dp(11),
            color=(0.3, 0.9, 0.6, 1),
            size_hint_y=0.05,
            halign='center',
            valign='middle'
        )
        overlay.add_widget(self.explanation_label)
        
        # چرخ شبدری
        self.clover = CloverWheel(
            self.controller.letters,
            size_hint_y=0.30,
            on_word_drawn=self.on_word_drawn
        )
        overlay.add_widget(self.clover)
        
        # دکمه‌ها
        hint_layout = GridLayout(cols=2, size_hint_y=0.08, spacing=dp(8), padding=[dp(15), 0, dp(15), 0])
        
        btn_hint = Button(
            text="Hint Letter\n(-5 🪙)",
            font_size=dp(11),
            font_name=FONT_BOLD,
            halign='center',
            background_color=(0.2, 0.4, 0.2, 1)
        )
        btn_hint.bind(on_press=self._on_hint)
        hint_layout.add_widget(btn_hint)
        
        btn_shuffle = Button(
            text="Shuffle\n(-1 🪙)",
            font_size=dp(11),
            font_name=FONT_BOLD,
            halign='center',
            background_color=(0.2, 0.3, 0.5, 1)
        )
        btn_shuffle.bind(on_press=self._on_shuffle)
        hint_layout.add_widget(btn_shuffle)
        overlay.add_widget(hint_layout)
        
        self.bonus_label = Label(
            text=f"🏺 Bonus Box: {len(self.controller.bonus_box)}/10",
            font_size=dp(10),
            color=(1, 0.5, 0, 1),
            size_hint_y=0.04
        )
        overlay.add_widget(self.bonus_label)
        
        # دکمه تبلیغات
        self.ad_button = Button(
            text="🎬 Watch Ad +20 🪙",
            font_size=dp(14),
            size_hint_y=0.06,
            background_color=(0.2, 0.5, 0.2, 1),
            color=(1, 0.85, 0, 1),
            disabled=False
        )
        self.ad_button.bind(on_press=self._watch_rewarded_ad)
        overlay.add_widget(self.ad_button)
        
        btn_interstitial = Button(
            text="📱 Interstitial Ad (+10 🪙)",
            font_size=dp(12),
            size_hint_y=0.05,
            background_color=(0.4, 0.2, 0.4, 1),
            color=(1, 1, 1, 1)
        )
        btn_interstitial.bind(on_press=self._show_interstitial_ad)
        overlay.add_widget(btn_interstitial)
    
    def _on_avatar_click(self, instance, touch):
        if instance.collide_point(*touch.pos):
            self.on_profile()
            return True
        return False
    
    def _update_ui(self):
        try:
            ctrl = self.controller
            self.coins_label.text = f"🪙 {ctrl.coins}"
            self.username_label.text = ctrl.username
            self.level_label.text = f"Stage {ctrl.current_level} - Tray {ctrl.current_tray}/20"
            self.bonus_label.text = f"🏺 Bonus Box: {len(ctrl.bonus_box)}/10"
            
            remaining = self.INTERSTITIAL_INTERVAL - self.stage_counter
            self.stage_counter_label.text = f"⏳ Next interstitial: {remaining} stages"
            
            self.words_grid.clear_widgets()
            for word in ctrl.main_words:
                row = BoxLayout(orientation='horizontal', spacing=dp(4), size_hint_y=None, height=dp(30))
                hint_chars = ctrl.get_hint_chars(word)
                
                if word in ctrl.guessed_words:
                    for char in word:
                        lbl = Label(text=char, font_name=FONT_BOLD, font_size=dp(18), color=(0, 1, 0.4, 1))
                        row.add_widget(lbl)
                else:
                    for idx, char in enumerate(word):
                        if idx in hint_chars:
                            lbl = Label(text=char, font_name=FONT_BOLD, font_size=dp(18), color=(1, 0.75, 0, 1))
                        else:
                            lbl = Label(text="_", font_name=FONT_BOLD, font_size=dp(18), color=(1, 1, 1, 1))
                        row.add_widget(lbl)
                self.words_grid.add_widget(row)
            
            self.words_grid.height = len(ctrl.main_words) * dp(32)
            self.clover.update_letters(ctrl.letters)
            
            if len(ctrl.guessed_words) == len(ctrl.main_words) and len(ctrl.main_words) > 0:
                self.msg_label.text = "🎉 All words found!"
                self.msg_label.color = (1, 0.8, 0, 1)
                Clock.schedule_once(self._next_tray, 2.0)
        except Exception as e:
            print(f"❌ Error updating UI: {e}")
    
    def _next_tray(self, dt):
        try:
            self.controller.next_tray()
            self._update_ui()
            self.msg_label.text = "🔮 New tray! Good luck!"
            self.msg_label.color = (1, 1, 1, 1)
            self.explanation_label.text = ""
            
            self.stage_counter += 1
            if self.stage_counter >= self.INTERSTITIAL_INTERVAL:
                self.stage_counter = 0
                Clock.schedule_once(self._show_auto_interstitial, 0.5)
        except Exception as e:
            print(f"❌ Error in next tray: {e}")
    
    def _show_auto_interstitial(self, dt):
        try:
            if self.app:
                if self.app.show_interstitial_ad():
                    self.msg_label.text = "📱 Interstitial ad displayed!"
                    self.msg_label.color = (0.6, 0.2, 0.8, 1)
                else:
                    self.msg_label.text = "⏳ Ad not available"
                    self.msg_label.color = (1, 0.5, 0, 1)
        except:
            pass
    
    def _show_interstitial_ad(self, instance):
        try:
            instance.disabled = True
            instance.text = "⏳ Loading Ad..."
            result = self.controller.watch_ad_interstitial()
            instance.disabled = False
            instance.text = "📱 Interstitial Ad (+10 🪙)"
            self._update_ui()
            self.msg_label.text = result["message"]
            self.msg_label.color = (0.6, 0.2, 0.8, 1)
            self._show_popup("🎉 Reward!", result["message"])
        except Exception as e:
            print(f"❌ Error in interstitial ad: {e}")
            instance.disabled = False
            instance.text = "📱 Interstitial Ad (+10 🪙)"
    
    def _watch_rewarded_ad(self, instance):
        try:
            instance.disabled = True
            instance.text = "⏳ Loading Ad..."
            result = self.controller.watch_ad_rewarded()
            instance.disabled = False
            instance.text = "🎬 Watch Ad +20 🪙"
            self._update_ui()
            self.msg_label.text = result["message"]
            self.msg_label.color = (0, 1, 0.4, 1)
            self._show_popup("🎉 Reward!", result["message"])
        except Exception as e:
            print(f"❌ Error in rewarded ad: {e}")
            instance.disabled = False
            instance.text = "🎬 Watch Ad +20 🪙"
    
    def on_word_drawn(self, word):
        try:
            result = self.controller.check_guess(word)
            self.msg_label.text = result["message"]
            
            if result["status"] in ["CORRECT", "TRAY_COMPLETED"]:
                self.msg_label.color = (0, 1, 0.4, 1)
                self._update_ui()
                word_found = result.get("word", word)
                explanation = get_word_explanation(word_found)
                self.explanation_label.text = f"💡 {explanation}"
            elif result["status"] in ["BONUS_ADDED", "BONUS_REWARD"]:
                self.msg_label.color = (1, 0.5, 0, 1)
                self._update_ui()
                self.explanation_label.text = ""
            else:
                self.msg_label.color = (1, 0.3, 0.3, 1)
                self.explanation_label.text = ""
        except Exception as e:
            print(f"❌ Error in word drawn: {e}")
    
    def _on_hint(self, instance):
        try:
            result = self.controller.use_hint()
            self.msg_label.text = result["message"]
            self.msg_label.color = (1, 0.8, 0, 1) if result["status"] == "SUCCESS" else (1, 0.3, 0.3, 1)
            self._update_ui()
        except:
            pass
    
    def _on_shuffle(self, instance):
        try:
            result = self.controller.use_shuffle()
            self.msg_label.text = result["message"]
            self.msg_label.color = (0.3, 0.8, 1, 1) if result["status"] == "SUCCESS" else (1, 0.3, 0.3, 1)
            self._update_ui()
        except:
            pass
    
    def _show_popup(self, title, message):
        try:
            content = BoxLayout(orientation='vertical', padding=10, spacing=10)
            content.add_widget(Label(text=message, font_name=FONT_REGULAR))
            btn = Button(text="OK", font_name=FONT_REGULAR, size_hint_y=None, height=40)
            popup = Popup(title=title, content=content, size_hint=(0.7, 0.3))
            btn.bind(on_press=popup.dismiss)
            content.add_widget(btn)
            popup.open()
        except:
            pass


# ============================================================
# Menu Screen
# ============================================================
class MenuScreen(BoxLayout):
    def __init__(self, controller, on_close, on_register, app=None, **kwargs):
        super(MenuScreen, self).__init__(**kwargs)
        self.orientation = 'vertical'
        self.padding = dp(20)
        self.spacing = dp(15)
        self.controller = controller
        self.on_close = on_close
        self.on_register = on_register
        self.app = app
        
        with self.canvas.before:
            Color(0.05, 0.1, 0.06, 1)
            self.bg = Rectangle(size=self.size, pos=self.pos)
        self.bind(size=self._update_bg, pos=self._update_bg)
        
        overlay = BoxLayout(orientation='vertical', padding=dp(20), spacing=dp(10))
        
        title = Label(text="☰ Game Menu", font_name=FONT_BOLD, font_size=dp(24), color=(1, 0.85, 0, 1), size_hint_y=0.08)
        overlay.add_widget(title)
        
        self.info_label = Label(
            text=f"Player: {controller.username}\nCoins: {controller.coins}\nTeam: {controller.team_name}",
            font_size=dp(14),
            color=(1, 1, 1, 1),
            size_hint_y=0.1,
            halign='center'
        )
        overlay.add_widget(self.info_label)
        
        avatar_label = Label(text="Select Avatar (Premium: 100 coins):", font_size=dp(14), color=(1, 1, 1, 1), size_hint_y=0.05)
        overlay.add_widget(avatar_label)
        
        avatar_scroll = ScrollView(size_hint_y=0.3)
        avatar_grid = GridLayout(cols=2, spacing=dp(5), size_hint_y=None)
        avatar_grid.bind(minimum_height=avatar_grid.setter('height'))
        
        for av in ALL_AVATARS:
            cost = get_avatar_cost(av["id"])
            btn = Button(
                text=f"{av['name']}\n{'💰 '+str(cost) if cost > 0 else '🆓'}",
                font_size=dp(10),
                size_hint_y=None,
                height=dp(50),
                background_normal=f'image/avatars/{av["id"]}.png' if os.path.exists(safe_resource_path(f'image/avatars/{av["id"]}.png')) else '',
                background_color=(1, 1, 1, 0.8)
            )
            btn.bind(on_press=lambda x, aid=av["id"], c=cost: self._select_avatar(aid, c))
            avatar_grid.add_widget(btn)
        avatar_scroll.add_widget(avatar_grid)
        overlay.add_widget(avatar_scroll)
        
        if not controller.is_registered:
            btn_register = Button(
                text="📝 Create Account",
                font_name=FONT_BOLD,
                font_size=dp(14),
                size_hint_y=0.06,
                background_color=(0.2, 0.5, 0.1, 1),
                color=(1, 0.85, 0, 1)
            )
            btn_register.bind(on_press=self._go_to_register)
            overlay.add_widget(btn_register)
        
        btn_close = Button(
            text="← Back to Game",
            font_name=FONT_BOLD,
            font_size=dp(16),
            size_hint_y=0.08,
            background_color=(0.3, 0.3, 0.5, 1),
            color=(1, 1, 1, 1)
        )
        btn_close.bind(on_press=self._close)
        overlay.add_widget(btn_close)
        
        self.add_widget(overlay)
    
    def _update_bg(self, *args):
        if hasattr(self, 'bg'):
            self.bg.size = self.size
            self.bg.pos = self.pos
    
    def _update_info(self):
        self.info_label.text = f"Player: {self.controller.username}\nCoins: {self.controller.coins}\nTeam: {self.controller.team_name}"
    
    def _select_avatar(self, avatar_id, cost):
        try:
            if self.controller.avatar_id == avatar_id:
                self._show_popup("Info", "Already using this avatar!")
                return
            if cost > 0 and self.controller.coins < cost:
                self._show_popup("Error", f"Need {cost} coins!")
                return
            if cost > 0:
                self.controller.coins -= cost
                update_user_coins(self.controller.user_uuid, self.controller.coins)
            self.controller.avatar_id = avatar_id
            update_user_avatar(self.controller.user_uuid, avatar_id)
            self._update_info()
            self._show_popup("Success", f"Avatar changed to {get_avatar_name(avatar_id)}!")
        except:
            pass
    
    def _go_to_register(self, instance):
        self.on_register()
    
    def _show_popup(self, title, message):
        try:
            content = BoxLayout(orientation='vertical', padding=10, spacing=10)
            content.add_widget(Label(text=message, font_name=FONT_REGULAR))
            btn = Button(text="OK", font_name=FONT_REGULAR, size_hint_y=None, height=40)
            popup = Popup(title=title, content=content, size_hint=(0.7, 0.3))
            btn.bind(on_press=popup.dismiss)
            content.add_widget(btn)
            popup.open()
        except:
            pass
    
    def _close(self, instance):
        self.on_close()


# ============================================================
# Profile Screen
# ============================================================
class ProfileScreen(BoxLayout):
    def __init__(self, controller, on_back, **kwargs):
        super(ProfileScreen, self).__init__(**kwargs)
        self.orientation = 'vertical'
        self.padding = dp(15)
        self.spacing = dp(10)
        self.controller = controller
        self.on_back = on_back
        
        with self.canvas.before:
            Color(0.05, 0.1, 0.06, 1)
            self.bg = Rectangle(size=self.size, pos=self.pos)
        self.bind(size=self._update_bg, pos=self._update_bg)
        
        overlay = BoxLayout(orientation='vertical', padding=dp(15), spacing=dp(10))
        
        title = Label(text="👤 My Profile", font_name=FONT_BOLD, font_size=dp(22), color=(1, 0.85, 0, 1), size_hint_y=0.06)
        overlay.add_widget(title)
        
        avatar_box = BoxLayout(size_hint_y=0.15, spacing=dp(10))
        avatar_img = get_avatar_image(self.controller.avatar_id, self.controller.user_uuid)
        if isinstance(avatar_img, Image):
            self.avatar_image = avatar_img
            self.avatar_image.size_hint = (None, None)
            self.avatar_image.size = (dp(80), dp(80))
            self.avatar_image.pos_hint = {'center_x': 0.5}
        else:
            self.avatar_image = Label(text="🖼️", font_size=dp(40), size_hint=(None, None), size=(dp(80), dp(80)), pos_hint={'center_x': 0.5})
        avatar_box.add_widget(self.avatar_image)
        overlay.add_widget(avatar_box)
        
        btn_upload = Button(
            text="📸 Upload Photo (Gallery)",
            font_size=dp(12),
            size_hint_y=0.06,
            background_color=(0.2, 0.3, 0.5, 1),
            color=(1, 1, 1, 1)
        )
        btn_upload.bind(on_press=self._upload_photo)
        overlay.add_widget(btn_upload)
        
        info = Label(
            text=f"Username: {controller.username}\n"
                 f"Coins: {controller.coins}\n"
                 f"Words Found: {controller.total_words_found}\n"
                 f"Level: {controller.current_level}\n"
                 f"Team: {controller.team_name}\n"
                 f"🏆 Wins: {controller.wins} | Losses: {controller.losses}",
            font_size=dp(13),
            color=(1, 1, 1, 1),
            size_hint_y=0.35,
            halign='left',
            valign='middle'
        )
        info.bind(size=info.setter('text_size'))
        overlay.add_widget(info)
        
        btn_back = Button(
            text="← Back to Game",
            font_size=dp(16),
            size_hint_y=0.08,
            background_color=(0.3, 0.3, 0.3, 1),
            color=(1, 1, 1, 1)
        )
        btn_back.bind(on_press=self._go_back)
        overlay.add_widget(btn_back)
        
        self.add_widget(overlay)
    
    def _update_bg(self, *args):
        if hasattr(self, 'bg'):
            self.bg.size = self.size
            self.bg.pos = self.pos
    
    def _upload_photo(self, instance):
        try:
            from plyer import filechooser
            filechooser.open_file(
                on_selection=self._handle_photo_selection,
                filters=[("Image files", "*.png;*.jpg;*.jpeg")]
            )
        except Exception as e:
            self._show_popup("Error", f"File chooser not available: {str(e)}")
    
    def _handle_photo_selection(self, selection):
        if not selection:
            return
        try:
            file_path = selection[0]
            avatar_key = save_custom_avatar(self.controller.user_uuid, file_path)
            if avatar_key:
                update_user_avatar(self.controller.user_uuid, avatar_key)
                self.controller.avatar_id = avatar_key
                self._update_avatar_display()
                self._show_popup("Success", "Photo uploaded successfully!")
            else:
                self._show_popup("Error", "Failed to save photo!")
        except Exception as e:
            self._show_popup("Error", f"Failed to upload: {str(e)}")
    
    def _update_avatar_display(self):
        try:
            avatar_path = get_avatar_image_path(self.controller.avatar_id, self.controller.user_uuid)
            parent = self.avatar_image.parent
            if parent:
                parent.clear_widgets()
                if avatar_path:
                    self.avatar_image = Image(source=avatar_path, size_hint=(None, None), size=(dp(80), dp(80)), pos_hint={'center_x': 0.5})
                else:
                    self.avatar_image = Label(text="🖼️", font_size=dp(40), size_hint=(None, None), size=(dp(80), dp(80)), pos_hint={'center_x': 0.5})
                parent.add_widget(self.avatar_image)
        except:
            pass
    
    def _go_back(self, instance):
        self.on_back()
    
    def _show_popup(self, title, message):
        try:
            content = BoxLayout(orientation='vertical', padding=10, spacing=10)
            content.add_widget(Label(text=message, font_name=FONT_REGULAR))
            btn = Button(text="OK", font_name=FONT_REGULAR, size_hint_y=None, height=40)
            popup = Popup(title=title, content=content, size_hint=(0.7, 0.3))
            btn.bind(on_press=popup.dismiss)
            content.add_widget(btn)
            popup.open()
        except:
            pass


# ============================================================
# Avatar helpers
# ============================================================
FREE_AVATARS = [
    {"id": "bald_boy", "name": "Bald Boy"},
    {"id": "bald_girl", "name": "Bald Girl"},
    {"id": "bald_old_man", "name": "Bald Old Man"},
    {"id": "bald_old_woman", "name": "Bald Old Woman"},
]

PREMIUM_AVATARS = [
    {"id": "baby", "name": "Baby", "cost": 100},
    {"id": "king", "name": "King", "cost": 100},
    {"id": "soldier", "name": "Soldier", "cost": 100},
    {"id": "hairy_man", "name": "Hairy Man", "cost": 100},
    {"id": "curly_man", "name": "Curly Man", "cost": 100},
    {"id": "big_head_man", "name": "Big Head Man", "cost": 100},
    {"id": "pretty_woman", "name": "Pretty Woman", "cost": 100},
    {"id": "handsome_man", "name": "Handsome Man", "cost": 100},
    {"id": "angry_man", "name": "Angry Man", "cost": 100},
    {"id": "strong_man", "name": "Strong Man", "cost": 100},
    {"id": "angry_woman", "name": "Angry Woman", "cost": 100},
    {"id": "strong_woman", "name": "Strong Woman", "cost": 100},
    {"id": "athlete_man", "name": "Athlete Man", "cost": 100},
    {"id": "athlete_woman", "name": "Athlete Woman", "cost": 100},
    {"id": "old_man", "name": "Old Man", "cost": 100},
]

ALL_AVATARS = FREE_AVATARS + PREMIUM_AVATARS

def get_avatar_name(avatar_id):
    for av in ALL_AVATARS:
        if av["id"] == avatar_id:
            return av["name"]
    return avatar_id

def get_avatar_cost(avatar_id):
    for av in PREMIUM_AVATARS:
        if av["id"] == avatar_id:
            return av["cost"]
    return 0


# ============================================================
# Run
# ============================================================
if __name__ == '__main__':
    LepreCoinApp().run()