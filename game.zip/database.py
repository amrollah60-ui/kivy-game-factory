# -*- coding: utf-8 -*-
"""
database.py - مدیریت دیتابیس و عملیات مرتبط
"""

import sqlite3
import json
import uuid
from datetime import datetime

DB_NAME = "leprecoin_game.db"

def init_database():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_uuid TEXT NOT NULL UNIQUE,
            username TEXT,
            email TEXT,
            google_id TEXT,
            wallet_address TEXT,
            coins INTEGER DEFAULT 150,
            avatar_id TEXT DEFAULT 'bald_boy',
            total_words_found INTEGER DEFAULT 0,
            current_level INTEGER DEFAULT 1,
            current_tray INTEGER DEFAULT 1,
            team_name TEXT DEFAULT 'No Team',
            is_registered BOOLEAN DEFAULT 0,
            wins INTEGER DEFAULT 0,
            losses INTEGER DEFAULT 0,
            is_online BOOLEAN DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            last_login TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS game_state (
            user_uuid TEXT PRIMARY KEY,
            bonus_box TEXT,
            guessed_words TEXT,
            revealed_hint_chars TEXT,
            FOREIGN KEY (user_uuid) REFERENCES users(user_uuid)
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_words (
            user_id INTEGER,
            word TEXT,
            found_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS matches (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            player1_uuid TEXT,
            player2_uuid TEXT,
            winner_uuid TEXT,
            score1 INTEGER DEFAULT 0,
            score2 INTEGER DEFAULT 0,
            rounds TEXT,
            status TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            completed_at TIMESTAMP,
            FOREIGN KEY (player1_uuid) REFERENCES users(user_uuid),
            FOREIGN KEY (player2_uuid) REFERENCES users(user_uuid)
        )
    ''')
    
    conn.commit()
    conn.close()

def get_user_by_uuid(user_uuid):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE user_uuid = ?", (user_uuid,))
    user = cursor.fetchone()
    conn.close()
    return user

def create_guest_user(user_uuid):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT INTO users (user_uuid, coins, avatar_id) VALUES (?, ?, ?)",
            (user_uuid, 150, "bald_boy")
        )
        conn.commit()
        user_id = cursor.lastrowid
    except sqlite3.IntegrityError:
        user_id = None
    conn.close()
    return user_id

def register_user(user_uuid, username, wallet_address):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    try:
        cursor.execute(
            "UPDATE users SET username = ?, wallet_address = ?, is_registered = 1 WHERE user_uuid = ?",
            (username, wallet_address, user_uuid)
        )
        conn.commit()
        success = True
    except sqlite3.IntegrityError:
        success = False
    conn.close()
    return success

def update_user_coins(user_uuid, coins):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET coins = ? WHERE user_uuid = ?", (coins, user_uuid))
    conn.commit()
    conn.close()

def update_user_avatar(user_uuid, avatar_id):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET avatar_id = ? WHERE user_uuid = ?", (avatar_id, user_uuid))
    conn.commit()
    conn.close()

def update_user_progress(user_uuid, level, tray):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET current_level = ?, current_tray = ? WHERE user_uuid = ?", (level, tray, user_uuid))
    conn.commit()
    conn.close()

def update_user_words_found(user_uuid, total):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET total_words_found = ? WHERE user_uuid = ?", (total, user_uuid))
    conn.commit()
    conn.close()

def update_user_stats(user_uuid, wins, losses):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET wins = ?, losses = ? WHERE user_uuid = ?", (wins, losses, user_uuid))
    conn.commit()
    conn.close()

def update_user_online(user_uuid, is_online):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET is_online = ? WHERE user_uuid = ?", (is_online, user_uuid))
    conn.commit()
    conn.close()

def save_game_state(user_uuid, bonus_box, guessed_words, revealed_hint_chars):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('''
        INSERT OR REPLACE INTO game_state (user_uuid, bonus_box, guessed_words, revealed_hint_chars)
        VALUES (?, ?, ?, ?)
    ''', (user_uuid, json.dumps(bonus_box), json.dumps(guessed_words), json.dumps(revealed_hint_chars)))
    conn.commit()
    conn.close()

def load_game_state(user_uuid):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("SELECT bonus_box, guessed_words, revealed_hint_chars FROM game_state WHERE user_uuid = ?", (user_uuid,))
    data = cursor.fetchone()
    conn.close()
    if data:
        return json.loads(data[0]), json.loads(data[1]), json.loads(data[2])
    return [], [], {}

def add_user_word(user_uuid, word):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("SELECT id FROM users WHERE user_uuid = ?", (user_uuid,))
    result = cursor.fetchone()
    if result:
        user_id = result[0]
        cursor.execute("INSERT INTO user_words (user_id, word) VALUES (?, ?)", (user_id, word))
        conn.commit()
    conn.close()

def get_all_users():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("SELECT id, username, avatar_id, coins, current_level, team_name, wins, losses, is_online, user_uuid FROM users WHERE is_registered = 1")
    users = cursor.fetchall()
    conn.close()
    return users

def get_leaderboard(limit=10):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute('''
        SELECT username, avatar_id, total_words_found, coins, wins, losses, user_uuid
        FROM users
        WHERE is_registered = 1
        ORDER BY total_words_found DESC
        LIMIT ?
    ''', (limit,))
    data = cursor.fetchall()
    conn.close()
    return data

def get_online_users():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("SELECT user_uuid, username, avatar_id, coins FROM users WHERE is_online = 1 AND is_registered = 1")
    users = cursor.fetchall()
    conn.close()
    return users

def create_dummy_users():
    """Create 20 dummy users for testing multiplayer with 400 coins each + 1 bot"""
    import random
    dummy_names = [
        "WordMaster", "LeprechaunKing", "CoinHunter", "PuzzlePro", "SpeedGuesser",
        "BrainStorm", "WordWizard", "GoldenTongue", "SwiftMind", "LexiconLord",
        "PuzzleMaster", "WordSage", "CoinCollector", "RiddleKing", "SmartPlayer",
        "QuickThinker", "WordGenius", "LuckyStar", "MindReader", "WordExplorer"
    ]
    
    avatars = ["bald_boy", "bald_girl", "bald_old_man", "bald_old_woman", "king", "queen", "soldier", "baby", "strong_man", "pretty_woman"]
    levels = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]
    words_found = [10, 25, 40, 15, 30, 20, 50, 18, 35, 12, 28, 45, 22, 32, 38, 16, 42, 27, 48, 14]
    
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    
    # پاک کردن کاربران قبلی ثبت‌نام شده
    cursor.execute("DELETE FROM users WHERE is_registered = 1")
    
    for i in range(20):
        user_uuid = str(uuid.uuid4())
        username = dummy_names[i % len(dummy_names)] + str(i+1)
        avatar = avatars[i % len(avatars)]
        coins = 400  # همه کاربران 400 سکه
        level = levels[i % len(levels)]
        words = words_found[i % len(words_found)]
        wins = random.randint(0, 10)
        losses = random.randint(0, 5)
        is_online = random.choice([0, 1])
        
        try:
            cursor.execute('''
                INSERT OR REPLACE INTO users 
                (user_uuid, username, avatar_id, coins, current_level, total_words_found, wins, losses, is_online, is_registered)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
            ''', (user_uuid, username, avatar, coins, level, words, wins, losses, is_online))
        except:
            pass
    
    # ===== بات با 400 سکه برای تست =====
    bot_uuid = str(uuid.uuid4())
    try:
        cursor.execute('''
            INSERT OR REPLACE INTO users 
            (user_uuid, username, avatar_id, coins, current_level, total_words_found, wins, losses, is_online, is_registered)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
        ''', (bot_uuid, "Bot_Alpha", "king", 400, 5, 30, 5, 3, 1))
    except:
        pass
    
    conn.commit()
    conn.close()
    print("✅ 20 dummy users created with 400 coins each!")
    print("✅ Bot_Alpha created with 400 coins for testing!")
    
    # به‌روزرسانی سکه کاربر قبلی (اگر وجود داشته)
    update_all_users_coins_to_400()

def update_all_users_coins_to_400():
    """به‌روزرسانی سکه همه کاربران ثبت‌نام شده به 400"""
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("UPDATE users SET coins = 400 WHERE is_registered = 1")
    conn.commit()
    conn.close()
    print("✅ All registered users coins updated to 400!")