[app]

# ============================================================
# اطلاعات اصلی
# ============================================================
title = LepreCoin
package.name = leprecoin
package.domain = org.leprecoin
version = 1.0.0

# ============================================================
# فایل اصلی
# ============================================================
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,webp,db,txt,json
version.regex = __version__ = ['"](.*)['"]
version.filename = online_game_kivy.py

# ============================================================
# کتابخانه‌ها
# ============================================================
requirements = python3,kivy,plyer,pillow,kivmob

# ============================================================
# تنظیمات صفحه
# ============================================================
orientation = portrait
fullscreen = 0
resizeable = 1

# ============================================================
# مجوزهای اندروید (کامل)
# ============================================================
android.permissions = INTERNET, ACCESS_NETWORK_STATE, READ_EXTERNAL_STORAGE, WRITE_EXTERNAL_STORAGE, READ_MEDIA_IMAGES, READ_MEDIA_VIDEO

# ============================================================
# تنظیمات SDK (کلیدی برای اندروید جدید)
# ============================================================
android.api = 33
android.minapi = 21
android.target_sdk = 33
android.ndk = 25b
android.sdk = 33
android.enable_androidx = True

# ============================================================
# AdMob
# ============================================================
android.gradle_dependencies = com.google.android.gms:play-services-ads:22.5.0
android.meta_data = com.google.android.gms.ads.APPLICATION_ID=ca-app-pub-3940256099942544~3347511713

# ============================================================
# معماری
# ============================================================
android.archs = arm64-v8a, armeabi-v7a
android.allow_backup = True
android.numeric_version = 1

# ============================================================
# تنظیمات iOS
# ============================================================
ios.codesign.allowed = false
ios.codesign.debug = false
ios.codesign.release = false

# ============================================================
# سطح لاگ
# ============================================================
log_level = 2